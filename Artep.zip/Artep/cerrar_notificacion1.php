<?php require 'conexion_bd.php';
    session_start();
    
    
 ?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<body style=" background: url('Le.jpeg') no-repeat; background-size: cover;">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Littelfuse. </title>

  



   <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/faviconS.png">
    <link rel="icon" type="image/favicon-s.png" sizes="32x32" href="assets/img/favicons/faviconS.png">

    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/faviconS.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="assets/css/theme.css" rel="stylesheet" />
<link rel="stylesheet" href="assets/css/jjjj.css">


<link rel="stylesheet" href="assets/css/TBusqueda0.css">


    

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

<style>
    @media(max-width: 991px){
        .navbar-search, .navbar-login {
            position:static !important;
        }
    }
</style>

  
  <!-- Bootstrap 5 js -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>

  </head>


  <body style=" background: url('xx.jpg') no-repeat; background-size: cover;">>
 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" href="main.css">
    <!-- GOOGLE FONTs -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <!-- ANIMATE CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <?php  
error_reporting(1);

// Archivo que contiene la clase de conexion a la BD


// creacion del objeto de la conexion a la BD
$obj = new BD_PDO();

// Toma de decision que corresponde al boton de insertar
if (isset($_POST['btninsertar'])) 
{
  if ($_POST['btninsertar']=='Insertar') 
  {
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(" INSERT INTO cerrar_notificacion (descripcion, descripcion_del_equipo, ubicacion_funcional, equipo, planta, SBU, fecha_iniciada, fecha_terminada, id_notificacion)VALUES 

    ('".$_POST['txtdescripcion']."',
     '".$_POST['txtdescripcion_del_equipo']."',
     '".$_POST['txtubicacion_funcional']."',
     '".$_POST['txtequipo']."',
     '".$_POST['txtplanta']."',
     '".$_POST['txtSBU']."',
     '".$_POST['txtfecha_iniciada']."',
     '".$_POST['txtfecha_terminada']."',
     '".$_POST['txtid_notificacion']."')");
     

   echo '<script type="text/javascript">alert("Se ha realizado la notificación.");</script>';
   }
  else
  {
  
  
 // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(  "update cerrar_notificacion SET 

                              descripcion = '".$_POST['txtdescripcion']."', 
                              descripcion_del_equipo = '".$_POST['txtdescripcion_del_equipo']."', 
                              ubicacion_funcional = '".$_POST['txtubicacion_funcional']."', 
                              equipo = '".$_POST['txtequipo']."', 
                              planta = '".$_POST['txtplanta']."',
                              SBU = '".$_POST['txtSBU']."', 
                              fecha_iniciada = '".$_POST['txtfecha_iniciada']."', 
                              fecha_terminada = '".$_POST['txtfecha_terminada']."',
                              id_notificacion = '".$_POST['txtid_notificacion']."'
                              where id_notificacion = '".$_POST['txtid_notificacion']."'");


    echo '<script type="text/javascript">alert("notificacion modificada correctamente.");</script>';

  }  

} 


if(isset($_POST['btnbuscar']))
{

$buscar = $obj->Ejecutar_Instruccion("select * from cerrar_notificacion where descripcion like '".$_POST['txtdescripcionbuscar']."'");

}

if (isset($_GET['id_eliminar'])) 
{
  $obj->Ejecutar_Instruccion("delete from cerrar_notificacion where id_notificacion = '".$_GET['id_eliminar']."'");

  echo '<script type="text/javascript">alert("notificacion eliminada correctamente.");</script>';
}
if (isset($_GET['id_modificar7'])) 
{
  $modificarA = $obj->Ejecutar_Instruccion("select * from cerrar_notificacion where id_notificacion = '".$_GET['id_modificar7']."'");

  $idmod = $obj->Ejecutar_Instruccion("select id_notificacion from cerrar_notificacion where id_notificacion= '".$_GET['id_modificar7']."'");

  $_SESSION['kikinasty7'] = $_GET['id_modificar7'];
}

 $notificacion = $obj->Ejecutar_Instruccion("Select * from notificacion");


 $cerrar_notificacion = $obj->Ejecutar_Instruccion("Select * from cerrar_notificacion");

$cerrar_notificacion= $obj->Ejecutar_Instruccion("select * from cerrar_notificacion where 1");
    ?>

<html lang="en">

<body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    




      <br>
      <br>
      <br>

      <section class="py-0" id="header">

        <br>
                    
        <!--/.bg-holder-->

        
        <!--/.bg-holder-->

</script>

<script type="text/javascript">
  
function Eliminar(id)
{
  if (confirm("¿Estas seguro de querer eliminar la notificacion?"))
    {
      location.href = "cerrar_notificacion1.php?id_eliminar=" + id;
    }
}



</script>

<script type="text/javascript">
  


function Modificar(id)
{
  if (confirm("¿Estas seguro de querer modificar la notificacion?"))
    {
      location.href = "cerrar_notificacion.php?id_modificar7=" + id;
    }
}



function Sololetras(e)
{
 
 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 123456789";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


</script>
   <main class="main" id="top">
      <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 bg-light opacity-55" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand" href="index.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/logo-s.png" alt="" width="30" /><td><br><span style = font-family:Impact>Littelfuse.</span></a>
         
          

           
     <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="index.php">Inicio.</a>



                        <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="notificacion.php">Notificacion.</a>



          </li>

            </ul>
            <form class="d-flex">
        
            </form>
          </div>
        </div>
      </nav>




        



<div>
</div>
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
        <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" href="#">
          <i class="fa fa-bell">
            <span class="badge badge-primary">LITTELFUSE.</span>
          </i>
         
        </a>
      </li>
     
     
      <li class="nav-item dropdown">
    
        <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" href="notificacion.php">
          <i class="fa fa-bell">
            <span class="badge badge-primary">Crear una notificación.</span>
          </i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="cerrar_notificacion.php">
          <i class="fa fa-globe">
            <span class="badge badge-primary">Buscar notificación.</span>
          </i>
        </a>
      </li>
    </ul>
</nav>
                   <br>  



  <form action="cerrar_notificacion1.php" method="post">  <div > 
 

   <a class="navbar-brand" href="#">
  </a>
  
</nav>

<br>

   <div align="center"> <h1 style = font-family:Impact class>Buscar Notificación.</h1> 
    <form action="cerrar_notificacion1.php" method="post" required>  
          






















      <br>
      <div class="row"> 
        <div class="col-lg-4" style="text-align: right;"> 
        <right>  <label style = font-family:Times New Roman class><FONT style = font-family:Impact class COLOR="black" for="">Descripción para buscar.</label> </H1> </FONT>   
        </div>
        <br>
        <div class="col-lg-4">
        <center>  <input type="text" id="txtdescripcionbuscar" name="txtdescripcionbuscar"  placeholder="Ingresar descripción para buscar." class="form-control" required="">
        </div>
        <br>
        <br>
        <br>
        <br>
        <div class="col-lg-3" align="right">
      <center>    <input type="submit" value="Buscar"  id="btnbuscar" name="btnbuscar" class="btn btn-primary btn-sm"  >
        </div>      
    
</div>
<form action="cerrar_notificacion1.php" method="post">  
        
<table class="table">
<table class="table table-success table-striped">


        <tr>



          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Descripción.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Descripción del equipo.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Ubicación funcional.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Equipo.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Planta.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">SBU.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Fecha Iniciada.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Fecha Terminada.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Id.</td>
          <td style = font-family:Times New Roman><FONT style = font-family:Impact class COLOR="black">Eliminar.</td>

        </tr>

        <?php if(isset($buscar)) { foreach ($buscar as $renglon3) {  ?>
        <tr>
          <td><?php echo $renglon3[0]; ?></td>
          <td><?php echo $renglon3[1]; ?></td>
          <td><?php echo $renglon3[2]; ?></td>
          <td><?php echo $renglon3[3]; ?></td>
          <td><?php echo $renglon3[4]; ?></td>
          <td><?php echo $renglon3[5]; ?></td>
          <td><?php echo $renglon3[6]; ?></td>
          <td><?php echo $renglon3[7]; ?></td>
          <td><?php echo $renglon3[8]; ?></td>



        

  

            <td><button type="button" class="btn-info btn-sm"  id="btneliminar"  name="btneliminar" onclick="javascript: Eliminar('<?php echo $renglon3[8]; ?>')" >Eliminar.</button></td>
  

          
        </tr>
        <?php } } else { ?>

        
        <?php foreach ($cerrar_notificacion as $renglon4) {  ?>
        <tr>
          <td><?php echo $renglon4[0]; ?></td>
          <td><?php echo $renglon4[1]; ?></td>
          <td><?php echo $renglon4[2]; ?></td>
          <td><?php echo $renglon4[3]; ?></td>
          <td><?php echo $renglon4[4]; ?></td>
          <td><?php echo $renglon4[5]; ?></td>
          <td><?php echo $renglon4[6]; ?></td>
          <td><?php echo $renglon4[7]; ?></td>
          <td><?php echo $renglon4[8]; ?></td>

  


            <td><button type="button" class="btnred btn-info btn-sm"  id="btneliminar"  name="btneliminar" onclick="javascript: Eliminar('<?php echo $renglon4[8]; ?>')" >Eliminar</button></td>
  
  
                


        </tr>
        <?php } }?>   
      </table>
    </form>
  </div>
      <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
   <a class="navbar-brand" href="#">
  </a>
  
    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="vendors/@popperjs/popper.min.js"></script>
    <script src="vendors/bootstrap/bootstrap.min.js"></script>
    <script src="vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="assets/js/theme.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Chivo:wght@300;400;700;900&amp;display=swap" rel="stylesheet">
  </body>

</html>