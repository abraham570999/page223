
    <h1>Busqueda.</h1> 
    <form action= usuarios.php method="post">  
          
      <br>
      <div class="row"> 
        <div class="col-lg-4" style="text-align: right;"> 
        <center>  <label><FONT COLOR="black" for="">Nombre para buscar.</label> </H1> </FONT>   
        </div>
        <div class="col-lg-4">
        <center>  <input type="text" id="txtnombrebuscar" name="txtnombrebuscar" placeholder="Buscar un usuario." onkeypress="return Sololetras(event)" class="form-control" required="">
        </div>
        <div class="col-lg-1" align="left">
      <center>  <input type="submit" value="Buscar"  id="btnbuscar" name="btnbuscar" class="btn btn-info"  >
        </div>      
    
</div>
    </form> </center>
      <br><br>
      <form action= usuarios.php method="post">  
        
      
      <center><table class="table table-yellow table-striped">
        <tr>
          <td>id</td>
          <td>nombre usuario</td>
          <td>correo</td>
          <td>password</td>
          <td>privilegio</td>
          <td>Eliminar</td>
          <td>Modificar</td>
        </tr>
        <?php if(isset($buscar)) { foreach ($buscar as $renglon2) {  ?>
        <tr>
          <td><?php echo $renglon2[0]; ?></td>
          <td><?php echo $renglon2[1]; ?></td>
          <td><?php echo $renglon2[2]; ?></td>
          <td><?php echo $renglon2[3]; ?></td>

        <td><button type="button" class="btnred btn-danger btn-sm"  id="btneliminar"  name="btneliminar" onclick="javascript: Eliminar('<?php echo $renglon2[3]; ?>')" >Eliminar</button></td>
  

                <td><button type="button" class="btnyellow btn-warning btn-sm"  id="btnmodificar"  name="btnmodificar" onclick="javascript: Modificar('<?php echo $renglon2[3]; ?>')" >Modificar</button></td>
          
        </tr>
        <?php } } else { ?>

        
        <?php foreach ( $usuarios as $renglon) {  ?>
        <tr>
          <td><?php echo $renglon[0]; ?></td>
          <td><?php echo $renglon[1]; ?></td>
          <td><?php echo $renglon[2]; ?></td>
          <td><?php echo $renglon[3]; ?></td>


            <td><button type="button" class="btnred btn-danger btn-sm"  id="btneliminar"  name="btneliminar" onclick="javascript: Eliminar('<?php echo $renglon[3]; ?>')" >Eliminar</button></td>
  

                <td><button type="button" class="btnyellow btn-warning btn-sm"  id="btnmodificar"  name="btnmodificar" onclick="javascript: Modificar('<?php echo $renglon[3]; ?>')" >Modificar</button></td>
   


        </tr>
        <?php } }?>   
      </table>
    </form>
  </div>