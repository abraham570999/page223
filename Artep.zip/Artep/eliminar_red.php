<?php


eliminar($_GET['id']);

function eliminar($id)

{
	
	include 'conexion_bd.php';
	$result="DELETE FROM notificacion WHERE id='".$id."' ";
	$conexion->query($result) or die ("error al eliminar".mysqli_error($conexion));


}

?>
<script type="text/javascript">
alert("eliminado!!");
window.location.href='Busqueda.php';
</script>