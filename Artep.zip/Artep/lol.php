<?php require 'conexion_bd.php';
    session_start();
    
   
    
    


    


$sql = "SELECT nombre_usuario1, DATE_FORMAT(fecha_de_mal_funcionamiento, '%d-%m-%Y') AS fecha_de_mal_funcionamiento, DATE_FORMAT(fecha_de_mal_funcionamiento, '%h:%m:%s %p') AS fecha_de_mal_funcionamiento FROM notificacion";

$result = mysqli_query(conexion_bd,$sql);


 ?>


<?php 

while ($registros = mysqli_fetch_array($result))

{

  ?>
  <p><strong><?php echo $registros["nombre_usuario1"]; ?></strong></p>
  <p>fecha de mal funcionamiento<?php echo $registros["fecha_de_mal_funcionamiento"]; ?></p>
<?php
}

 ?>
