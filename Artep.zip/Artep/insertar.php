<?php
$connect = mysqli_connect("localhost", "root", "", "littelfuse");
if(!empty($_POST))
{
 $output = '';
 $descripcion = mysqli_real_escape_string($connect, $_POST["descripcion"]);  
 $descripcion_del_equipo = mysqli_real_escape_string($connect, $_POST["descripcion_del_equipo"]);  
 $ubicacion_funcional = mysqli_real_escape_string($connect, $_POST["ubicacion_funcional"]);  
 $equipo = mysqli_real_escape_string($connect, $_POST["equipo"]);  
 $planta = mysqli_real_escape_string($connect, $_POST["planta"]);
 $SBU = mysqli_real_escape_string($connect, $_POST["SBU"]);
 $nombre_usuario1 = mysqli_real_escape_string($connect, $_POST["nombre_usuario1"]);
 $fecha_de_mal_funcionamiento = mysqli_real_escape_string($connect, $_POST["fecha_de_mal_funcionamiento"]);

    $query = " INSERT INTO notificacion(descripcion, descripcion_del_equipo, ubicacion_funcional, equipo, planta, SBU, nombre_usuario1, fecha_de_mal_funcionamiento)  
     VALUES('$descripcion', '$descripcion_del_equipo', '$ubicacion_funcional', '$equipo', '$planta', '$SBU', '$nombre_usuario1', '$fecha_de_mal_funcionamiento')";
    if(mysqli_query($connect, $query))
    {
     $output.= '<label class="text-success">Registro Insertado Correctamente</label>';
     $select_query = "SELECT * FROM notificacion ORDER BY id DESC";
     $result = mysqli_query($connect, $select_query);
     $output.='

     <table class="table table-dark">

         <tr>  
       <th width="30%">descripcio</th>  
       <th width="10%">descripcion_del_equipo</th>  
       <th width="10%">ubicacion_funcional</th>  
       <th width="30%">equipo</th>  
       <th width="10%">planta</th> 
              <th width="10%">SBU</th> 
       <th width="10%">Reportado Por:</th> 
       <th width="10%">fecha_de_mal_funcionamiento</th> 

        </tr>';
     while($row = mysqli_fetch_array($result))
     {
      $output .= '<tr>  
       <td>'.$row["descripcion"].'</td>
       <td>'.$row["descripcion_del_equipo"].'</td>
       <td>'.$row["ubicacion_funcional"].'</td>
       <td>'.$row["equipo"].'</td>
              <td>'.$row["planta"].'</td>
       <td>'.$row["SBU"].'</td>
       <td>'.$row["nombre_usuario1"].'</td>
       <td>'.$row["fecha_de_mal_funcionamiento"].'</td>

       <td><input type="button" name="view" value="Vista Previa" id="' . $row["id"] . '" class="btn btn-info btn-xs view_data" /></td>  
        </tr>';
     }
     $output.= '</table>';
    }
    echo $output;
}
?>