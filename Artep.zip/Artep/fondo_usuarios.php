?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php

?>

    <?php 
  error_reporting(1); 


  ?>
<html lang="en">


<body style=" background: url('ll.jpeg') no-repeat; background-size: cover;">
  	

 
  <div style="width: 800px; height: 400px; border: 1px black solid; background: url('ll.jpeg') no-repeat; background-size: cover;"></div>

  

  </body>
</html>
