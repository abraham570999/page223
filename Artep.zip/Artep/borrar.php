<?php

include_once('conexion_bd.php');

header('Location: Busqueda.php');
$id = isset( $_GET['id'] ) ? $_GET['id'] : 0;
borrar($id);
die();