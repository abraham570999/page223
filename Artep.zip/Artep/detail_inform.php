<?php  
//index.php
$connect = mysqli_connect("localhost", "root", "", "littelfuse");
$query = "SELECT * FROM notificacion ORDER BY id DESC";
$result = mysqli_query($connect, $query);
 ?>  


<?php require 'conexion_bd.php';
    session_start(1);
  ?>



<!DOCTYPE html>  
<html>  
 <head>  
  <br>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      <!-- Custom styles for this template -->


 </head>  
 <body>  

<?php  
// creacion del objeto de la conexion a la BD

// Toma de decision que corresponde al boton de insertar
if (isset($_POST['btninsertar'])) 
{
  if ($_POST['btninsertar']=='Insertar') 
  {
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(" INSERT INTO notificacion (descripcion, descripcion_del_equipo, ubicacion_funcional, equipo, planta, SBU, nombre_usuario1, fecha_de_mal_funcionamiento, id)VALUES 



    ('".$_POST['txtdescripcion']."',
     '".$_POST['txtdescripcion_del_equipo']."',
     '".$_POST['txtubicacion_funcional']."',
     '".$_POST['txtequipo']."',
     '".$_POST['txtplanta']."',
     '".$_POST['txtSBU']."',
     '".$_POST['txtnombre_usuario1']."',
     '".$_POST['txtfecha_inicio']."',
     '".$_POST['txtfecha_terminada']."',
     '".$_POST['txtid']."')");
     
   echo '<script type="text/javascript">alert("Se ha realizado la notificación.");</script>';
   }
  else
  {
  
  
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(  "update notificacion SET 



                                  descripcion = '".$_POST['txtdescripcion']."', 
                                   descripcion_del_equipo = '".$_POST['txtdescripcion_del_equipo']."', 
                  ubicacion_funcional = '".$_POST['txtubicacion_funcional']."', 
                                            equipo = '".$_POST['txtequipo']."', 
                                            planta = '".$_POST['txtplanta']."',
                                                  SBU = '".$_POST['txtSBU']."', 
                              nombre_usuario1 = '".$_POST['txtnombre_usuario1']."',  
 
                                       id = '".$_POST['txtid']."' 
                                where id = '".$_POST['txtid']."'");



    echo '<script type="text/javascript">alert("notificacion modificada correctamente.");</script>';

  }  

  }  



if(isset($_POST['btnbuscar']))
{

$buscar = $obj->Ejecutar_Instruccion("select * from notificacion ");

}

if (isset($_GET['id_eliminar'])) 
{
  $obj->Ejecutar_Instruccion("delete from notificacion where id = '".$_GET['id_eliminar']."'");

  echo '<script type="text/javascript">alert("notificacion eliminada correctamente.");</script>';
}
if (isset($_GET['id_modificar'])) 
{
  $modificarx = $obj->Ejecutar_Instruccion("select * from notificacion where id = '".$_GET['id_modificar']."'");

  $idmod = $obj->Ejecutar_Instruccion("select id from notificacion where id= '".$_GET['id_modificar']."'");

  $_SESSION['kikinasty'] = $_GET['id_modificar'];
}





    ?>

        <div class="container"><a class="navbar-brand" href="index.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/logo-s.png" alt="" width="50" /><br><span style = font-family:Impact>Littelfuse.</span></a>
          <br>

          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
             
     <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="#">ADMINISTRAR NOTIFICACIONES.</a>

  

                        <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="notificacion.php">Notificacion.</a>



           
            </ul>
            <form class="d-flex">
        
            </form>
          </div>
        </div>
      </nav>



    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Littelfuse.</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Inicio</a></li>
            <li><a href="notificacion.php">Crear una notificación.</a></li>
            <li><a href="search.php">Buscar notificación.</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    

      <!-- Begin page content -->
    <div class="container" style=" width:1000px">
      <div class="page-header">
         <h3 align="center" style = font-family:Impact>Detalle De La Notificación.</h3>
      </div>
      
   

<br>
        <div class="row">
        <div class="col-lg-2"></div>
        <div class="col-lg-1"><label hidden style = font-family:Impact >Estado.</label></div>
        <div class="col-lg-6">
        
      
                          <br>
        <div align="center" hidden style = font-family:Times New Roman class="col-lg-1"><label style = font-family:Impact  >Fecha del fallo:</label></div>
        <div class="col-lg-0">

              </div>
    

    <div align="center">   
<div class="col-lg-8">









<div align="center">
     


        <div class="col-lg-4">
         <div class="row"> 
        </div>
       
        <div class="col-lg-3" align="right">
        </div>      
    
</div>

 

<form action="search.php" method="post">  
        
        <div class="col-lg-3"></div>
      </div>
      <br>
    </div>    
  </div>
  </form>
</div>
<br>



  
          






<div></div>









<br>
</div>
   <br />  
   <div class="table-responsive">
    <div align="right">
     <button type="button" name="age" id="age" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-primary">Agregar Notificación.</button>
    </div>
    <br />
    <div id="employee_table">
     <table class="table table-bordered">
      <tr>
       <th width="30%">Descripción.</th>  
       <th width="10%">Descripción del equipo.</th>  
       <th width="10%">Ubicación funcional.</th>  
       <th width="30%">Equipo.</th>  
       <th width="30%">Planta.</th>  
       <th width="30%">SBU.</th>  
       <th width="30%">Reportado por.</th>  
       <th width="10%">Fecha Fallo.</th>
        <th width="10%">Vista</th> 

      </tr>

      <?php
      while($row = mysqli_fetch_array($result))
      {
      ?>
      <tr>

       <td><?php echo $row["descripcion"]; ?></td>
       <td><?php echo $row["descripcion_del_equipo"]; ?></td>
       <td><?php echo $row["ubicacion_funcional"]; ?></td>
       <td><?php echo $row["equipo"]; ?></td>
       <td><?php echo $row["planta"]; ?></td>
       <td><?php echo $row["SBU"]; ?></td>
       <td><?php echo $row["nombre_usuario1"]; ?></td>
              <td><?php echo $row["fecha_de_mal_funcionamiento"]; ?></td>

       <td><input type="button" name="view" value="Vista Previa" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>
      </tr>
      <?php
      }
      ?>
     </table>
    </div>
   </div>  
  </div>
  
  
  
    <footer class="footer">
      <div class="container">
        <p class="text-muted">Bienvenidos.<a href="https://www.baulphp.com/" target="_blank"></a></p>
      </div>
    </footer>



<div id="add_data_Modal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Ingresar Notificacion</h4>
   </div>
   <div class="modal-body">
    <form method="post" id="insert_form">
     <label>Ingrese descripcion</label>
     <input type="text" name="descripcion" id="descripcion" class="form-control" />
     <br />
     <label>Descripcion del equipo</label>
     <textarea name="descripcion_del_equipo" id="descripcion_del_equipo" class="form-control"></textarea>
     <br />
     <label>Ubicacion Funcional</label>
     <select name="ubicacion_funcional" id="ubicacion_funcional" class="form-control">
      <option value="Hombre">Hombre</option>  
      <option value="Mujer">Mujer</option>
     </select>
     <br />  
     <label>equipo</label>
     <input type="text" name="equipo" id="equipo" class="form-control" />
     <br />  
     <label>planta</label>
     <input type="text" name="planta" id="planta" class="form-control" />
     <br />
      <label>SBU</label>
     <input type="text" name="SBU" id="SBU" class="form-control" />
     <br />
      <label>nombre usuario1</label>
     <input type="text" name="nombre_usuario1" id="nombre_usuario1" class="form-control" />
     <br />
      <label>fecha de mal funcionamiento</label>
     <input type="datetime-local" name="fecha_de_mal_funcionamiento" id="fecha_de_mal_funcionamiento" class="form-control" />
     <br />
     <input type="submit" name="insert" id="insert" value="Agregar Notificación." class="btn btn-success" />

    </form>
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>

   </div>
  </div>
 </div>
</div>








<script type="text/javascript">
  
function Eliminar(id)
{
  if (confirm("¿Estas seguro de querer eliminar la notificacion?"))
    {
      location.href = "notificacion.php?id_eliminar=" + id;
    }
}



</script>

<script type="text/javascript">
  



function Modificar1(id)
{
  if (confirm("¿Estas seguro de querer modificar la notificacion?"))
    {
      location.href = "notificacion.php?id_modificar=" + id;
    }
}



function Modificar(id)
{
  if (confirm("¿Estas seguro de querer modificar la notificacion?"))
    {
      location.href = "cerrar_notificacion.php?id_modificar=" + id;
    }
}



function Sololetras(e)
{
 
 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 1234567890";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


</script>
















<div id="dataModal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Detalle Notificación.</h4>
   </div>
   <div class="modal-body" id="notificacion_detalles">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>





   </div>
  </div>
 </div>
</div>

<script>  
$(document).ready(function(){
 $('#insert_form').on("submit", function(event){  
  event.preventDefault();  
  if($('#name').val() == "")  
  {  
   alert("Name is required");  
  }  
  else if($('#address').val() == '')  
  {  
   alert("Address is required");  
  }  
  else if($('#designation').val() == '')
  {  
   alert("Designation is required");  
  }
   
  else  
  {  
   $.ajax({  
    url:"insertar.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#employee_table').html(data);  
    }  
   });  
  }  
 });




 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var notificacion_id = $(this).attr("id");
  $.ajax({
   url:"VistaPrevia.php",
   method:"POST",
   data:{notificacion_id:notificacion_id},
   success:function(data){
    $('#notificacion_detalles').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
});  
 </script>

 </body>  
</html>