
<!DOCTYPE html>
<html lang="en">
<head>
	<?php 
error_reporting(1);

// Archivo que contiene la clase de conexion a la BD
require 'conexion_bd.php';

// creacion del objeto de la conexion a la BD
$obj = new BD_PDO();

// Toma de decision que corresponde al boton de insertar
if (isset($_POST['btninsertar'])) 
{
	if ($_POST['btninsertar']=='Insertar') 
	{
		// Instruccion sql para insertar un registro en la tabla categoria
		$obj->Ejecutar_Instruccion("INSERT INTO categorias(nombre, descripcion) VALUES ('".$_POST['txtnombres']."','".$_POST['txtdescripcion']."')");

	 echo '<script type="text/javascript">alert("Se ha registrado la categoría.");</script>';
	}
	else
	{
		
		// Instruccion sql para insertar un registro en la tabla categoria
		$obj->Ejecutar_Instruccion("update categorias SET 
			nombre = '".$_POST['txtnombres']."', 
			descripcion = '".$_POST['txtdescripcion']."'
			where id_categoria = '".$_POST['txtid']."'");

		echo '<script type="text/javascript">alert("categoría modificado correctamente.");</script>';

	}	
}
if(isset($_POST['btnbuscar']))
{

$buscar = $obj->Ejecutar_Instruccion("select * from categorias where nombre like '".$_POST['txtnombrebuscar']."'");

}

if (isset($_GET['id_eliminar'])) 
{
	$obj->Ejecutar_Instruccion("delete from categorias where id_categoria = '".$_GET['id_eliminar']."'");

	echo '<script type="text/javascript">alert("Categoría eliminada.");</script>';
}
if (isset($_GET['id_modificar'])) 
{
	$modificarx = $obj->Ejecutar_Instruccion("select * from categorias where id_categoria = '".$_GET['id_modificar']."'");

	$idmod = $obj->Ejecutar_Instruccion("select id from categorias where id_categoria = '".$_GET['id_modificar']."'");

	$_SESSION['kikinasty'] = $_GET['id_modificar'];
}


// Instruccion sql para realizar una busqueda en la tabla de categoria
// Variable $categoria contendra los registros encontrados al realizarse la ejecucion de la consulta sql
$categorias = $obj->Ejecutar_Instruccion("select * from categorias where 1");
             ?>

<center>         <h1 class="nav-item"><a class="nav-link js-scroll-trigger"  align="center" href="index.php">Inicio</h1>

	
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

<div style="background-image: url(artep2.jpg); background-repeat: no-repeat; background-size: 1720px 1300px" >


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


<nav class="navbar navbar-expand-md navbar-white fixed-top bg-white">
            <a class="navbar-brand" href="index.php"><FONT COLOR="black" for=""> </label> </H3> </FONT></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
              <ul class="navbar-nav mr-auto">
         
                 <li class="nav-item">
                  <a class="nav-link" href="index.php"><FONT COLOR="black" for="">Inicio.</label> </H3> </FONT> <span class="sr-only"></span></a>
                </li>
               <li class="nav-item">
                  <a class="nav-link" href="proveedores.php"><FONT COLOR="black" for="">Proveedores.</label> </H3> </FONT> <span class="sr-only"></span></a>
                </li>
              
                <?php if($_SESSION['privilegio']==2) {?>
				<li class="nav-item">
                  <a class="nav-link"><FONT COLOR="black" for="">ADMIN</label> </H3> </FONT> <span class="sr-only"></span></a>
                </li>           

                <li class="nav-item">
                  <a class="nav-link" href="exit.php"><FONT COLOR="black" for="">Cerrar Sesion</label> </H3> </FONT> <span class="sr-only"></span></a>
                </li>
            <?php } ?>
              </ul>
            </div>
</nav>
	<meta charset="UTF-8">
	<title>Categorías</title>


	 <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container d-flex justify-content-between">
      <a href="#" class="navbar-brand d-flex align-items-center"> 

      </a>
    </div>
  </div>
</head>
 		

<body>
<div style="background-image: url(fondo.png); background-repeat: no-repeat; background-size: 1920px 1080px">

<script type="text/javascript">
	
function Eliminar(id)
{
	if (confirm("¿Estas seguro de querer eliminar el registro?"))
		{
			location.href = "categoria.php?id_eliminar=" + id;
		}
}



</script>

<script type="text/javascript">
	


function Modificar(id)
{
	if (confirm("¿Estas seguro de querer modificar el registro?"))
		{
			location.href = "categoria.php?id_modificar=" + id;
		}
}


function Sololetras(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
	if (tecla == letras[i])
      { 

      	estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 123456789";

for(var i = 0; i < letras.length ; i++)

{ 
	if (tecla == letras[i])
      { 

      	estatus = true;
   
   }

   }

   return estatus;

   }









</script>
	 <body background="estudio.jpg"  id="page-top">  
		<form action="categoria.php" method="post">  <div > 
	<div class="container" > <div class="container" > 
		<div class="text-center"> <div align="to top" style=" background: linear-gradient(to
      bottom,#f3ffe9, white);  } width: %; box-shadow: 26px 20px 15px;
 border-radius: 20px 20px 15px "align="center">

<br>


		<center>	<h1>Registro de Categoría</h1> 
			
  
			<div class="row" hidden> 
				<div class="col-lg-4"></div> 
				<div class="row" hidden> 
				<div class="col-lg-4"></div> 
				<div class="col-lg-4">
					<input type="text" id="txtid" name="txtid" placeholder="Id" class="form-control" value="<?php echo $modificarx[0]['id_categoria']; ?>">
				</div>
				<div class="col-lg-4"></div>
			</div>
				<div class="col-lg-4"></div>
			</div>


		


				<div class="row">
				<div class="col-lg-2"></div>
				<div class="col-lg-1"><label>Nombre de categoría.</label></div>
				<div class="col-lg-6">
					<input type="text" id="txtnombres" name="txtnombres" placeholder="Ingresar categoría." minlength="1" maxlength="100"  class="form-control" value="<?php echo @$modificarx[0][0]; ?>" required>
				</div>

	

	             <!-- STOCK -->
              
		
			
			</div>
			

<br>

<div class="row">
				<div class="col-lg-2"></div>
				<div class="col-lg-1"><label>Descipción.</label></div>
				<div class="col-lg-6">
					<textarea type="text" id="txtdescripcion" name="txtdescripcion" class="form-control" placeholder="Ingresar descipción." minlength="1" maxlength="200" onkeypress="return Sololetras(event) Solonumeros(event)"  class="form-control" value="<?php echo @$modificarx[0][1]; ?>" required ></textarea>
					<br>
				</div>
			</div>





			<div class="row">
				<div class="col-lg-3"></div>
				<div class="col-lg-6">
					<br>
					<input type="submit"  id="btninsertar" name="btninsertar" class="btn btn-info" value="<?php 
						if (isset($_GET['id_modificar']))
						{
							echo 'Modificar';
						}
						else
						{
							echo 'Insertar';
						}			 ?>" >
				</div>
				<div class="col-lg-3"></div>
			</div>
			<br>
		</div>		
	</div>
	</form>
</div>

<td>
	<br>
<br>
<br>
<br>
      <div >  
	   
		<form action="categoria.php" method="post">  <div > 
	<div class="container" > <div class="container" > 
		<div align="to top" style=" background: linear-gradient(to
      bottom,#f3ffe9,white );  } width: %; box-shadow: 26px 20px 15px;
 border-radius: 20px 20px 15px "align="center">

	<center>	<h1>Busqueda.</h1> 
		<form action="categoria.php" method="post">  
          
			<br>
			<div class="row"> 
				<div class="col-lg-4" style="text-align: right;"> 
					<center><label><FONT COLOR="black" for="">Buscar categoría.</label> </H3> </FONT>   
				</div>
				<div class="col-lg-4">
					<input type="text" id="txtnombrebuscar" name="txtnombrebuscar" placeholder="Ingresar categoría." class="form-control" required="">
				</div>
				<div class="col-lg-1" align="left">
				<center>	<input type="submit" value="Buscar"  id="btnbuscar" name="btnbuscar" class="btn btn-info"  >
				</div>			
			</div>	

		</form>
			<br><br>
			<form action="categoria.php" method="post">  
				
			
			<table class="table table-dark table-striped">
				<tr>
					<td>Categoria.</td>
					<td>Descripcion categoria.</td>
					<td>ID.</td>
					<td>Eliminar</td>
					<td>Modificar</td>
				</tr>
				<?php if(isset($buscar)) { foreach ($buscar as $renglon2) {  ?>
				<tr>
					<td><?php echo $renglon2[0]; ?></td>
					<td><?php echo $renglon2[1]; ?></td>
					<td><?php echo $renglon2[2]; ?></td>
						
			 <td><button type="button" class="btnred btn-danger btn-sm"  id="btneliminar"  name="btneliminar" onclick="javascript: Eliminar('<?php echo $renglon[2]; ?>')"  >Eliminar</button></td>
  

                <td><button type="button" class="btnyellow btn-warning btn-sm"  id="btnmodificar"  name="btnmodificar" onclick="javascript: Modificar('<?php echo $renglon[2]; ?>')" >Modificar</button></td>
				</tr>
				<?php } } else { ?>

				
				<?php foreach ($categorias as $renglon) {  ?>
				<tr>
					<td><?php echo $renglon[0]; ?></td>
					<td><?php echo $renglon[1]; ?></td>
					<td><?php echo $renglon[2]; ?></td>
			
		        <td><button type="button" class="btnred btn-danger btn-sm"  id="btneliminar"  name="btneliminar" onclick="javascript: Eliminar('<?php echo $renglon[2]; ?>')"  >Eliminar</button></td>
  

                <td><button type="button" class="btnyellow btn-warning btn-sm"  id="btnmodificar"  name="btnmodificar" onclick="javascript: Modificar('<?php echo $renglon[2]; ?>')" >Modificar</button></td>
   
				</tr>


				<?php } }?>		
			</table>
		</form>
	</div>
	<!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  </div>
</body>
</html>