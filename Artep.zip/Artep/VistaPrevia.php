<?php  
//select.php  
if(isset($_POST["notificacion_id"]))
{
 $output = '';
 $connect = mysqli_connect("localhost", "root", "", "littelfuse");
 $query = "SELECT * FROM notificacion WHERE id = '".$_POST["notificacion_id"]."'";
 $result = mysqli_query($connect, $query);
 $output .= '  



      <div class="table-responsive">  
           <table class="table table-bordered">';
    while($row = mysqli_fetch_array($result))
    {
     $output .= '
     <tr>  
            <td width="30%"><label>Descripción.</label></td>  
            <td width="70%">'.$row["descripcion"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Dirección del equipo.</label></td>  
            <td width="70%">'.$row["descripcion_del_equipo"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Ubicación Funcional.</label></td>  
            <td width="70%">'.$row["ubicacion_funcional"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Equipo.</label></td>  
            <td width="70%">'.$row["equipo"].'</td>  
        </tr>
        <tr>  
            <td width="30%"><label>Planta.</label></td>  
            <td width="70%">'.$row["planta"].'</td>  
        </tr>
         <tr>  
            <td width="30%"><label>SBU.</label></td>  
            <td width="70%">'.$row["SBU"].'</td>  
        </tr>
         <tr>  
            <td width="30%"><label>Reportado Por:</label></td>  
            <td width="70%">'.$row["nombre_usuario1"].'</td>  
        </tr>

         <tr>  
            <td width="30%"><label>Fecha fallo.</label></td>  
            <td width="70%">'.$row["fecha_de_mal_funcionamiento"].'</td>  
        </tr>


         
     ';
    }
    $output .= '</table></div>';
    echo $output;


}
?>
