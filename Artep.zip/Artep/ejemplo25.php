<?php


ini_set('date.timezone', 'America/Mexico_City');

$time1 = date('H:i:s', time());

$time2 = date('Y-m-d, H:i:s', time());

echo date("g:i a",strtotime(time1));

print '<br>';

echo $time2.'<br>';

?>