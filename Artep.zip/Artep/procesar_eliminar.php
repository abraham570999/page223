<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php while ($notificacion = $consult->fetch_assoc())
 {

?>


	<tr>
		

<td><?php echo "notificacion"['id'];?> </td>
<td><?php echo "notificacion"['descripcion'];?> </td>
<td><?php echo "notificacion"['descripcion_de_equipo'];?> </td>
<td><?php echo "notificacion"['ubicacion_funcional'];?> </td>
<td><?php echo "notificacion"['equipo'];?> </td>
<td><?php echo "notificacion"['planta'];?> </td>
<td><?php echo "notificacion"['SBU'];?> </td>
<td><?php echo "notificacion"['nombre_usuario1'];?> </td>
<td><?php echo "notificacion"['fecha_de_mal_funcionamiento'];?> </td>
<a href="borrar.php"  class="btn btn-warning" onclick="preguntar(<?php echo $notificacion['id']; ?>)">Eliminar</a>
	</tr>
}

<script type="text/javascript">
function preguntar(id){

	if (confirm('¿esta seguro de eliminar el registro con id ' + id +'?')) {

		window.location.href = "borrar.php?id=" + id;


	}
	

</script>



</body>
</html>


