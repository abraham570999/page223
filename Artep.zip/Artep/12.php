
<?php  
echo "<table border =1>";
while($rs=mysql_fetch_array($sql))
  {
  echo "<tr>
          <td>".$rs['MARCA']."</td>
          <td>".$rs['MODELO']."</td>
          <td>".$rs['MOTORIZACION']."</td>
          <td>".$rs['COMBUSTIBLE']."</td>
          <td>".$rs['ACELERACION']."</td>
          <td>".$rs['POTENCIA']."</td>
          <td>".$rs['CONSUMO']."</td>
          <td>".$rs['PRECIO']."</td>
          <td><a href='modificar.php?ID=".$rs['ID']."'>Editar</a></td>
        </tr>";
  }
 echo "<table>"; ?>