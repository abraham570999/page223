<?php  
//index.php
$connect = mysqli_connect("localhost", "root", "", "littelfuse");
$query = "SELECT * FROM notificacion ORDER BY id DESC";
$result = mysqli_query($connect, $query);
 ?>  


<?php require 'conexion_bd.php';
    session_start(1);
  ?>



<!DOCTYPE html>  
<html>  
 <head>  
  <br>
  <title>Busqueda Notificación.</title>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      <!-- Custom styles for this template -->


 </head>  
 <body>  

<?php  
// creacion del objeto de la conexion a la BD

// Toma de decision que corresponde al boton de insertar
if (isset($_POST['btninsertar'])) 
{
  if ($_POST['btninsertar']=='Insertar') 
  {
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(" INSERT INTO notificacion (descripcion, descripcion_del_equipo, ubicacion_funcional, equipo, planta, SBU, nombre_usuario1, fecha_de_mal_funcionamiento, id)VALUES 



    ('".$_POST['txtdescripcion']."',
     '".$_POST['txtdescripcion_del_equipo']."',
     '".$_POST['txtubicacion_funcional']."',
     '".$_POST['txtequipo']."',
     '".$_POST['txtplanta']."',
     '".$_POST['txtSBU']."',
     '".$_POST['txtnombre_usuario1']."',
     '".$_POST['txtfecha_de_mal_funcionamiento']."',
     '".$_POST['txtid']."')");
     
   echo '<script type="text/javascript">alert("Se ha realizado la notificación.");</script>';
   }
  else
  {
  
  
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(  "update notificacion SET 



                                  descripcion = '".$_POST['txtdescripcion']."', 
                                   descripcion_del_equipo = '".$_POST['txtdescripcion_del_equipo']."', 
                  ubicacion_funcional = '".$_POST['txtubicacion_funcional']."', 
                                            equipo = '".$_POST['txtequipo']."', 
                                            planta = '".$_POST['txtplanta']."',
                                                  SBU = '".$_POST['txtSBU']."', 
                              nombre_usuario1 = '".$_POST['txtnombre_usuario1']."',  
 
                                       id = '".$_POST['txtid']."' 
                                where id = '".$_POST['txtid']."'");



    echo '<script type="text/javascript">alert("notificacion modificada correctamente.");</script>';

  }  

  }  



if(isset($_POST['btnbuscar']))
{

$buscar = $obj->Ejecutar_Instruccion("select * from notificacion ");

}

if (isset($_GET['id_eliminar'])) 
{
  $obj->Ejecutar_Instruccion("delete from notificacion where id = '".$_GET['id_eliminar']."'");

  echo '<script type="text/javascript">alert("notificacion eliminada correctamente.");</script>';
}
if (isset($_GET['id_modificar'])) 
{
  $modificarx = $obj->Ejecutar_Instruccion("select * from notificacion where id = '".$_GET['id_modificar']."'");

  $idmod = $obj->Ejecutar_Instruccion("select id from notificacion where id= '".$_GET['id_modificar']."'");

  $_SESSION['kikinasty'] = $_GET['id_modificar'];
}





    ?>

        <div class="container"><a class="navbar-brand" href="index.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/logo-s.png" alt="" width="50" /><br><span style = font-family:Impact>Littelfuse.</span></a>
          <br>

          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
             
     <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="#">ADMINISTRAR NOTIFICACIONES.</a>

  

                        <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="notificacion.php">Notificacion.</a>



           
            </ul>
            <form class="d-flex">
        
            </form>
          </div>
        </div>
      </nav>



    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Littelfuse.</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Inicio</a></li>
            <li><a href="notificacion.php">Crear una notificación.</a></li>
            <li><a href="Busqueda.php">Buscar notificación.</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    

      <!-- Begin page content -->
    <div class="container" style=" width:900px">
      <div class="page-header">
         <h3 align="center">Busqueda Notificación.</h3> 
      </div>
      
   


<h1> <center>  <pre style = font-family:Impact>Administrar Notificación.</pre></h1>
      
      <br>
      <div class="row">

                          <div class="col-lg-3"></div>
        <div style="color=white" class="col-lg-1"><label style = font-family:Impact>Numero Notificación:</label></div>
        <div class="col-lg-5">

        <center>  <input type="text" id="txtidbuscar" name="txtidbuscar" onkeypress="return Solonumeros(event)" minlength="0" maxlength="14" required  placeholder="Ingresar numero de notificación para buscar." class="form-control" required>
        </div>
        <div class="col-lg-4"></div>
      </div>

<br>


<br>
         
      <br>

          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label   style = font-family:impact>Ubicación funcional:</label></div>
        <div class="col-lg-5">

             <select class="form-control" type="text" id="txtubicacion_funcionalbuscar" name="txtubicacion_funcionalbuscar" 
              value="<?php echo @$modificarx[0][2]; ?>" 
              >  </p>

              
                  <option value="">Por Favor, Seleccione uno.</option>
                  <option value="D1 - Des Plaines Facility." <?php if ($modificarx[0]['ubicacion_funcional']=='D1 - Des Plaines Facility.'){echo 'Selected';} ?>>D1 - Des Plaines Facility.</option>

                  <option >D1-A - Des Plaines - Automotive.</option>

                  <option value="D1-A-501 - Des Plaines - Automotive - Molding." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-501 - Des Plaines - Automotive - Molding.'){echo 'Selected';} ?> value="ubicacion_funcional">D1-A-501 - Des Plaines - Automotive - Molding.</option>

                  <option value="D1-A-502 Des Plaines - Automotive - Punch Press." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-502 Des Plaines - Automotive - Punch Press.'){echo 'Selected';} ?>>D1-A-502 Des Plaines - Automotive - Punch Press.</option>

                  <option value="D1-A-503 Des Plaines - Automotive - Four Slide." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-503 Des Plaines - Automotive - Four Slide.'){echo 'Selected';} ?>>D1-A-503 Des Plaines - Automotive - Four Slide.</option>

                  <option value="D1-A-504 Des Plaines - Automotive - Plating." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-504 Des Plaines - Automotive - Plating.'){echo 'Selected';} ?>>D1-A-504 Des Plaines - Automotive - Plating.</option>

                  <option value="D1-A-508 Des Plaines - Automotive - Fuse Plating." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-508 Des Plaines - Automotive - Fuse Plating.'){echo 'Selected';} ?>>D1-A-508 Des Plaines - Automotive - Fuse Plating.</option>

                  <option value="D1-A-509 Des Plaines - Automotive - Skiving." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-509 Des Plaines - Automotive - Skiving.'){echo 'Selected';} ?>>D1-A-509 Des Plaines - Automotive - Skiving.</option>

                  <option value="D1-A-520 Des Plaines - Automotive - Jcase." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-520 Des Plaines - Automotive - Jcase.'){echo 'Selected';} ?>>D1-A-520 Des Plaines - Automotive - Jcase.</option>

                  <option value="D1-A-522 Des Plaines - Automotive - Mini Fuse." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-522 Des Plaines - Automotive - Mini Fuse.'){echo 'Selected';} ?>>D1-A-522 Des Plaines - Automotive - Mini Fuse.</option>

                  <option value="D1-A-523 Des Plaines - Automotive - Maxi Fuse." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-523 Des Plaines - Automotive - Maxi Fuse.'){echo 'Selected';} ?>>D1-A-523 Des Plaines - Automotive - Maxi Fuse.</option>

                  <option value="D1-A-525 Des Plaines - Automotive - ATO/Mini Diode." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.'){echo 'Selected';} ?>>D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.</option>

                  <option value="D1-A-543 Des Plaines - Automotive - Molding Mini." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-543 Des Plaines - Automotive - Molding Mini.'){echo 'Selected';} ?>>D1-A-543 Des Plaines - Automotive - Molding Mini.</option>

                  <option value="D1-A-544 Des Plaines - Automotive - Molding Maxi." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-544 Des Plaines - Automotive - Molding Maxi.'){echo 'Selected';} ?>>D1-A-544 Des Plaines - Automotive - Molding Maxi.</option>

                  <option value="D1-A-545 Des Plaines - Automotive - Molding ATO." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-545 Des Plaines - Automotive - Molding ATO.'){echo 'Selected';} ?>>D1-A-545 Des Plaines - Automotive - Molding ATO.</option>

                  <option value="D1-A-546 Des Plaines - Automotive - Molding Jcase." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-546 Des Plaines - Automotive - Molding Jcase.'){echo 'Selected';} ?>>D1-A-546 Des Plaines - Automotive - Molding Jcase.</option>

                  <option value="D1-A-592 Des Plaines - Automotive - Inspection." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-592 Des Plaines - Automotive - Inspection.'){echo 'Selected';} ?>>D1-A-592 Des Plaines - Automotive - Inspection.</option>

                  <option value="D1-A-593 Des Plaines - Automotive - Product Eval." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-593 Des Plaines - Automotive - Product Eval.'){echo 'Selected';} ?>>D1-A-593 Des Plaines - Automotive - Product Eval.</option>

                  <option value="D1-E Des Plaines - Electronics." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E Des Plaines - Electronics.'){echo 'Selected';} ?>>D1-E Des Plaines - Electronics.</option>

                  <option value="D1-E-504 Des Plaines - Electronics - Plating." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-504 Des Plaines - Electronics - Plating.'){echo 'Selected';} ?>>D1-E-504 Des Plaines - Electronics - Plating.</option>

                  <option value="D1-E-510 Des Plaines - Electronics - Pulse Gard." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-510 Des Plaines - Electronics - Pulse Gard.'){echo 'Selected';} ?>>D1-E-510 Des Plaines - Electronics - Pulse Gard.</option>

                  <option value="D1-E-512 Des Plaines - Electronics - 0402." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-512 Des Plaines - Electronics - 0402.'){echo 'Selected';} ?>>D1-E-512 Des Plaines - Electronics - 0402.</option>

                  <option value="D1-E-514 Des Plaines - Electronics - Slim 1206." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-514 Des Plaines - Electronics - Slim 1206.'){echo 'Selected';} ?>>D1-E-514 Des Plaines - Electronics - Slim 1206.</option>

                  <option value="D1-E-515 Des Plaines - Electronics - Stencil/Dice." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-515 Des Plaines - Electronics - Stencil/Dice.'){echo 'Selected';} ?>>D1-E-515 Des Plaines - Electronics - Stencil/Dice.</option>

                  <option value="D1-E-516 Des Plaines - Elec - Surface Mnt Telecom." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-516 Des Plaines - Elec - Surface Mnt Telecom.'){echo 'Selected';} ?>>D1-E-516 Des Plaines - Elec - Surface Mnt Telecom.</option>

                  <option value="D1-E-517 Des Plaines - Electronics - Inspection." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-517 Des Plaines - Electronics - Inspection.'){echo 'Selected';} ?>>D1-E-517 Des Plaines - Electronics - Inspection.</option>

                  <option value="D1-E-518 Des Plaines - Elec - Compounding/Extrusn." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-518 Des Plaines - Elec - Compounding/Extrusn.'){echo 'Selected';} ?>>D1-E-518 Des Plaines - Elec - Compounding/Extrusn.</option>

                  <option value="D1-E-519 Des Plaines - Electronics - Thim Film." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-519 Des Plaines - Electronics - Thim Film.'){echo 'Selected';} ?>>D1-E-519 Des Plaines - Electronics - Thim Film.</option>

                  <option value="D1-E-532 Des Plaines - Electronics - Drilling." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-532 Des Plaines - Electronics - Drilling.'){echo 'Selected';} ?>>D1-E-532 Des Plaines - Electronics - Drilling.</option>

                       </select>
        </div>
        
      </div>

    

      <br>
      <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>Equipo:</label></div>
        <div class="col-lg-5">

        <center>  <p>    <input type="text" id="txtequipo" name="txtequipo" style = font-family: placeholder="Por favor, seleccione uno." minlength="" maxlength="" onkeypress="return (event)" class="form-control" value="<?php echo @$modificarx[0][3]; ?>" > </p>

          </div>
      </div>

       <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>Planta:</label></div>
        <div class="col-lg-5">

      

<select class="form-control" id="txtplantabuscar" name="txtplantabuscar"  value="<?php echo @$modificarx[0][4] ?>">
                  <option value="">Por Favor, Seleccione uno.</option>
         <option value="">Por Favor, Seleccione uno.</option>
                  <option value="99 - Littelfuse - Mexico Auto Mfg." <?php if ($modificarx[0]['planta']=='99 - Littelfuse - Mexico Auto Mfg.'){echo 'Selected';} ?>>99 - Littelfuse - Mexico Auto Mfg.</option>

                  <option value="A1 - Littelfuse Inc." <?php if ($modificarx[0]['planta']=='A1 - Littelfuse Inc.'){echo 'Selected';} ?>>A1 - Littelfuse Inc.</option>

                  <option value="B1 - Littelfuse-Brazil." <?php if ($modificarx[0]['planta']=='B1 - Littelfuse-Brazil.'){echo 'Selected';} ?>>B1 - Littelfuse-Brazil.</option>

                  <option value="BS1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BS1 - Littelfuse, Inc.'){echo 'Selected';} ?>>BS1 - Littelfuse, Inc.</option>

                  <option value="BT1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BT1 - Littelfuse, Inc.'){echo 'Selected';} ?>>BT1 - Littelfuse, Inc.</option>

                  <option value="BV1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BV1 - Littelfuse, Inc.'){echo 'Selected';} ?>>BV1 - Littelfuse, Inc.</option>

                  <option value="BT1S - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BT1S - Littelfuse, Inc.'){echo 'Selected';} ?>>BT1S - Littelfuse, Inc.</option>

                  <option value="BVWS - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BVWS - Littelfuse, Inc.'){echo 'Selected';} ?>>BVWS - Littelfuse, Inc.</option>

                  <option value="BW1 - SSAC." <?php if ($modificarx[0]['planta']=='BW1 - SSAC.'){echo 'Selected';} ?>>BW1 - SSAC.</option>

                  <option value="C1 - Littelfuse, Centralia." <?php if ($modificarx[0]['planta']=='C1 - Littelfuse, Centralia.'){echo 'Selected';} ?>>C1 - Littelfuse, Centralia.</option>

                  <option value="CN1 - LF Suzhou OVS Ltd.(Export)" <?php if ($modificarx[0]['planta']=='CN1 - LF Suzhou OVS Ltd.(Export)'){echo 'Selected';} ?>>CN1 - LF Suzhou OVS Ltd.(Export)</option>

                  <option value="CN2 - LF Suzhou OVS Ltd.(Domestiq)" <?php if ($modificarx[0]['planta']=='CN2 - LF Suzhou OVS Ltd.(Domestiq)'){echo 'Selected';} ?>>CN2 - LF Suzhou OVS Ltd.(Domestiq)</option>

                  <option value="CN3 - LF Hamlin Electronics Ltd." <?php if ($modificarx[0]['planta']=='CN3 - LF Hamlin Electronics Ltd.'){echo 'Selected';} ?>>CN3 - LF Hamlin Electronics Ltd.</option>

                  <option value="D1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='D1 - Littelfuse, Inc.'){echo 'Selected';} ?>>D1 - Littelfuse, Inc.</option>

                  <option value="D1S - LITTELFUSE - D.P. Samples." <?php if ($modificarx[0]['planta']=='D1S - LITTELFUSE - D.P. Samples.'){echo 'Selected';} ?>>D1S - LITTELFUSE - D.P. Samples.</option>

                  <option value="D2 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='D2 - Littelfuse, Inc.'){echo 'Selected';} ?>>D2 - Littelfuse, Inc.</option>

                  <option value="DE1 - Littelfuse GmbH - D.P. Samples." <?php if ($modificarx[0]['planta']=='DE1 - Littelfuse GmbH - D.P. Samples.'){echo 'Selected';} ?>>DE1 - Littelfuse GmbH - D.P. Samples.</option>

                  <option value="DG1 - LF - Dongguan." <?php if ($modificarx[0]['planta']=='DG1 - LF - Dongguan.'){echo 'Selected';} ?>>DG1 - LF - Dongguan.</option>

                  <option value="DG2 - LF - Dongguan." <?php if ($modificarx[0]['planta']=='DG2 - LF - Dongguan.'){echo 'Selected';} ?>>DG2 - LF - Dongguan.</option>

                  <option value="DN1 - Littelfuse Europe GmbH." <?php if ($modificarx[0]['planta']=='DN1 - Littelfuse Europe GmbH.'){echo 'Selected';} ?>>DN1 - Littelfuse Europe GmbH.</option>

                  <option value="DN1S -Littelfuse GmbH - Samples." <?php if ($modificarx[0]['planta']=='DN1S -Littelfuse GmbH - Samples.'){echo 'Selected';} ?>>DN1S -Littelfuse GmbH - Samples.</option>

                  <option value="DN2 - Littelfuse Holding GmbH." <?php if ($modificarx[0]['planta']=='DN2 - Littelfuse Holding GmbH.'){echo 'Selected';} ?>>DN2 - Littelfuse Holding GmbH.</option>

                  <option value="E2 - Electric Sales Unlimited." <?php if ($modificarx[0]['planta']=='E2 - Electric Sales Unlimited.'){echo 'Selected';} ?>>E2 - Electric Sales Unlimited.</option>

                  <option value="F1 - LFFE - Hong Kong Dist. Ctr." <?php if ($modificarx[0]['planta']=='F1 - LFFE - Hong Kong Dist. Ctr.'){echo 'Selected';} ?>>F1 - LFFE - Hong Kong Dist. Ctr.</option>

                  <option value="F2 - LFFE - Hong Kong Dist. Ctr." <?php if ($modificarx[0]['planta']=='F2 - LFFE - Hong Kong Dist. Ctr.'){echo 'Selected';} ?>>F2 - LFFE - Hong Kong Dist. Ctr.</option>

                  <option value="G1 - G'Day Aftermarket Warehouse." <?php if ($modificarx[0]['planta']=='G1 - G Day Aftermarket Warehouse.'){echo 'Selected';} ?>>G1 - G'Day Aftermarket Warehouse.</option>

                  <option value="GB1 - Obsolete." <?php if ($modificarx[0]['planta']=='GB1 - Obsolete.'){echo 'Selected';} ?>>GB1 - Obsolete.</option>

                  <option value="HK1 - Littelfuse Hong Kong Limited." <?php if ($modificarx[0]['planta']=='HK1 - Littelfuse Hong Kong Limited.'){echo 'Selected';} ?>>HK1 - Littelfuse Hong Kong Limited.</option>

                  <option value="HN1 - Hamlin UK." <?php if ($modificarx[0]['planta']=='HN1 - Hamlin UK.'){echo 'Selected';} ?>>HN1 - Hamlin UK.</option>

                  <option value="11 - Obsolete." <?php if ($modificarx[0]['planta']=='11 - Obsolete.'){echo 'Selected';} ?>>11 - Obsolete.</option>


                       </select>
          </div>
      </div> 
      <br>

 <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>SBU:</label></div>
        <div class="col-lg-5">

  
       <select class="form-control"  id="txtSBUbuscar" name="txtSBUbuscar"  value="<?php echo @$modificarx[0][5] ?>">
                  <option value="">Por Favor, Seleccione uno.</option>
                  <option value="ABU" <?php if ($modificarx[0]['SBU']=='ABU'){echo 'Selected';} ?>>ABU</option>
                  <option value="CVP" <?php if ($modificarx[0]['SBU']=='CVP'){echo 'Selected';} ?>>CVP</option>
                  <option value="EBU" <?php if ($modificarx[0]['SBU']=='EBU'){echo 'Selected';} ?>>EBU</option>
                  <option value="PBU" <?php if ($modificarx[0]['PBU']==''){echo 'Selected';} ?>>PBU</option>
                  <option value="SBU" <?php if ($modificarx[0]['SBU']=='SBU'){echo 'Selected';} ?>>SBU</option>
                       


                       </select>
          </div>
      </div>
<br>
        <div class="row">
        <div class="col-lg-2"></div>
        <div class="col-lg-1"><label style = font-family:Impact >Estado.</label></div>
        <div class="col-lg-6">
        
       <select class="form-control" id="txtstatus" name="txtstatus" placeholder="Ingresar 1 para buscar." class="form-control">
                  <option  value="">Todos.</option>
                  <option value="producto">Abiertos.</option>
                  <option value="Servicio">Terminado.</option>
                       </select>

                 <div></div>           


                          <br>
        <div align="center" style = font-family:Times New Roman class="col-lg-1"><label style = font-family:Impact  >Fecha del fallo:</label></div>
        <div class="col-lg-0">

              </div>
    

    <div align="center">   
<div class="col-lg-8">

<p> <input align="center"  style="display:"  accept="application/pdf" type="datetime-local" id="txtfecha_de_mal_funcionamiento" name="txtfecha_de_mal_funcionamiento" class="form-control" class="col-md-7" value="?><?php 
ini_set('date.timezone', 'America/Mexico_City');

$date = date("g:i a",strtotime(date('H:i:s', time()+00300)));

 ?>" class="form-control" ></p>








<div align="center">
     


        <div class="col-lg-4">
         <div class="row"> 
        </div>
       
        <div class="col-lg-3" align="right">
        </div>      
    
</div>

  <p><button value="Buscar" id="btnbuscar" name="btnbuscar" class="btn btn-primary btn-sm" type="submit">Buscar</button></p>


<form action="search.php" method="post">  
        
        <div class="col-lg-3"></div>
      </div>
      <br>
    </div>    
  </div>
  </form>
</div>
<br>



  
          






<div></div>









<br>
</div>
   <br />  
   <div class="table-responsive">
    <div align="right">
     <button type="button" name="age" id="age" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-primary">Agregar Notificación.</button>
    </div>
    <br />
    <div id="employee_table">
     <table class="table table-bordered">
      <tr>
       <th width="30%">Descripción.</th>  
       <th width="10%">Descripción del equipo.</th>  
       <th width="10%">Ubicación funcional.</th>  
       <th width="30%">Equipo.</th>  
       <th width="30%">Planta.</th>  
       <th width="30%">SBU.</th>  
       <th width="30%">Reportado por.</th>  
       <th width="30%">Fecha de mal funcionamiento.</th>  
       <th width="10%">Vista.</th>
      </tr>
      <?php
      while($row = mysqli_fetch_array($result))
      {
      ?>
      <tr>

       <td><?php echo $row["descripcion"]; ?></td>
       <td><?php echo $row["descripcion_del_equipo"]; ?></td>
       <td><?php echo $row["ubicacion_funcional"]; ?></td>
       <td><?php echo $row["equipo"]; ?></td>
       <td><?php echo $row["planta"]; ?></td>
       <td><?php echo $row["SBU"]; ?></td>
       <td><?php echo $row["nombre_usuario1"]; ?></td>
       <td><?php echo $row["fecha_de_mal_funcionamiento"]; ?></td>

       <td><input type="button" name="view" value="Vista Previa" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>
      </tr>
      <?php
      }
      ?>
     </table>
    </div>
   </div>  
  </div>
  
  
  
    <footer class="footer">
      <div class="container">
        <p class="text-muted">Bienvenidos.<a href="https://www.baulphp.com/" target="_blank"></a></p>
      </div>
    </footer>



<div id="add_data_Modal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Ingresar Notificacion</h4>
   </div>
   <div class="modal-body">
    <form method="post" id="insert_form">
     <label>Ingrese descripcion</label>
     <input type="text" name="descripcion" id="descripcion" class="form-control" />
     <br />
     <label>Descripcion del equipo</label>
     <textarea name="descripcion_del_equipo" id="descripcion_del_equipo" class="form-control"></textarea>
     <br />
     <label>Ubicacion Funcional</label>
     <select name="ubicacion_funcional" id="ubicacion_funcional" class="form-control">
      <option value="Hombre">Hombre</option>  
      <option value="Mujer">Mujer</option>
     </select>
     <br />  
     <label>equipo</label>
     <input type="text" name="equipo" id="equipo" class="form-control" />
     <br />  
     <label>planta</label>
     <input type="text" name="planta" id="planta" class="form-control" />
     <br />
      <label>SBU</label>
     <input type="text" name="SBU" id="SBU" class="form-control" />
     <br />
      <label>nombre usuario1</label>
     <input type="text" name="nombre_usuario1" id="nombre_usuario1" class="form-control" />
     <br />
      <label>fecha de mal funcionamiento</label>
     <input type="datetime-local" name="fecha_de_mal_funcionamiento" id="fecha_de_mal_funcionamiento" class="form-control" />
     <br />
     <input type="submit" name="insert" id="insert" value="Agregar Notificación." class="btn btn-success" />

    </form>
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>

   </div>
  </div>
 </div>
</div>








<script type="text/javascript">
  
function Eliminar(id)
{
  if (confirm("¿Estas seguro de querer eliminar la notificacion?"))
    {
      location.href = "notificacion.php?id_eliminar=" + id;
    }
}



</script>

<script type="text/javascript">
  



function Modificar1(id)
{
  if (confirm("¿Estas seguro de querer modificar la notificacion?"))
    {
      location.href = "notificacion.php?id_modificar=" + id;
    }
}



function Modificar(id)
{
  if (confirm("¿Estas seguro de querer modificar la notificacion?"))
    {
      location.href = "cerrar_notificacion.php?id_modificar=" + id;
    }
}



function Sololetras(e)
{
 
 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 1234567890";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


</script>
















<div id="dataModal" class="modal fade">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Detalle Notificación.</h4>
   </div>
   <div class="modal-body" id="notificacion_detalles">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>




   </div>
  </div>
 </div>
</div>

<script>  
$(document).ready(function(){
 $('#insert_form').on("submit", function(event){  
  event.preventDefault();  
  if($('#name').val() == "")  
  {  
   alert("Name is required");  
  }  
  else if($('#address').val() == '')  
  {  
   alert("Address is required");  
  }  
  else if($('#designation').val() == '')
  {  
   alert("Designation is required");  
  }
   
  else  
  {  
   $.ajax({  
    url:"insertar.php",  
    method:"POST",  
    data:$('#insert_form').serialize(),  
    beforeSend:function(){  
     $('#insert').val("Inserting");  
    },  
    success:function(data){  
     $('#insert_form')[0].reset();  
     $('#add_data_Modal').modal('hide');  
     $('#employee_table').html(data);  
    }  
   });  
  }  
 });




 $(document).on('click', '.view_data', function(){
  //$('#dataModal').modal();
  var notificacion_id = $(this).attr("id");
  $.ajax({
   url:"VistaPrevia.php",
   method:"POST",
   data:{notificacion_id:notificacion_id},
   success:function(data){
    $('#notificacion_detalles').html(data);
    $('#dataModal').modal('show');
   }
  });
 });
});  
 </script>

 </body>  
</html>