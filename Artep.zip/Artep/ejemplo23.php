<?php //Ejemplo curso PHP aprenderaprogramar.com


echo date("g:i a", strtotime("America/Mexico_City"));

?>


<?php

    $date = '';

    echo date('g:i a', strtotime("America/Mexico_City"));