 <? php 
sesión_inicio (); 
$sesiónDatos = ! vacío ( $_SESSION [ 'sessData' ])? $_SESSION [ 'datossesión' ]: '' ; if (! vacío ( $sessData [ 'status' ][ 'msg' ])){     $statusMsg = $sessData [ 'status' ][ 'msg' ];     $statusMsgType = $sessData [ 'estado' ][ 'tipo' ];     desarmado ( 



$_SESSION [ 'sessData' ][ 'estado' ]); } ?> < h2 > Introduzca el correo electrónico de su cuenta para restablecer la nueva contraseña </ h2 > <? eco php ! vacío ( $statusMsg )? '<p class="' . $statusMsgType. '">' . $estadoMensaje. '</p>' : '' ; ?> < clase div = "contenedor" > < clase div = "regisFrm"



 
 
     
         action = "userAccount.php" method = "post" > < input type = "email" name = "email" placeholder = "EMAIL" required = "" > < div class = "send-button" > < input type = " enviar" nombre = "forgotSubmit" valor = "CONTINUAR" > </ div > </ formulario > </ div > </ 
                
             
                   
            
        
    
división >