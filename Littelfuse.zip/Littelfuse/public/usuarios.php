<?php require 'conexion_bd.php';
    session_start();
  
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php 

error_reporting(1);
// Archivo que contiene la clase de conexion a la BD


// creacion del objeto de la conexion a la BD
$obj = new BD_PDO();

// Toma de decision que corresponde al boton de insertar
if (isset($_POST['btnregistrar'])) 
{
  if ($_POST['btnregistrar']=='Registrar Usuario') 
  {
    // Instruccion sql para insertar un registro en la tabla  
    $obj->Ejecutar_Instruccion("INSERT INTO usuarios(id_usuario, nombre_usuario, correo, password, privilegio)
     VALUES 
        ('".$_POST['txtid_usuario']."',
     '".$_POST['txtnombre_usuario']."',
             '".$_POST['txtcorreo']."',
           '".$_POST['txtpassword']."'
         'Admin')");
     
   echo '<script type="text/javascript">alert("Se ha registrado el usuario.");</script>';
  }
  else
  {
    
    // Instruccion sql para insertar un registro en la tabla usuarios
    $obj->Ejecutar_Instruccion("update usuarios SET   
                    nombre_usuario = '".$_POST['txtnombre_usuario']."', 
                                    correo = '".$_POST['txtcorreo']."', 
                                password = '".$_POST['txtpassword']."'
                             where id_usuario  = '".$_POST['txtid']."'");

    echo '<script type="text/javascript">alert("usuario modificado correctamente.");</script>';

  } 
}
if(isset($_POST['btnbuscar']))
{

$buscar = $obj->Ejecutar_Instruccion("select * from usuarios where nombre_usuario like '".$_POST['txtnombrebuscar']."'");

}

if (isset($_GET['id_eliminar'])) 
{
  $obj->Ejecutar_Instruccion("delete from usuarios where id_usuario = '".$_GET['id_eliminar']."'");

  echo '<script type="text/javascript">alert("usuario eliminado.");</script>';
}
if (isset($_GET['id_modificar'])) 
{
  $modificarx = $obj->Ejecutar_Instruccion("select * from usuarios where id_usuario = '".$_GET['id_modificar']."'");

  $idmod = $obj->Ejecutar_Instruccion("select id_usuario from usuarios where id_usuario = '".$_GET['id_modificar']."'");

  $_SESSION['kikinasty'] = $_GET['id_modificar'];

  

}

 

 $usuarios = $obj->Ejecutar_Instruccion("Select * from usuarios");

// Instruccion sql para realizar una busqhueda en la tabla de usuarios
// Variable  usuarios contendra los registros encontrados al realizarse la ejecucion de la consulta sql
 $usuarios = $obj->Ejecutar_Instruccion("select * from usuarios where 1");
             ?>
<html lang="en">

<body>


  <meta charset="utf-8">
    <title>Littelfuse.</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sssss.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  </head>
    <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label li clas="active" class="logo" href="index.php">Littelfuse.</label></li>
      <ul>
       <div align="left"> <li><a  class="active" href="index.php">Página Principal.</a></li>
     
      </ul>
    </nav>


</html>
<body style=" background: url('ll.jpg') no-repeat; background-size: cover;">
      
  <meta charset="UTF-8">
  <title> usuarios</title>



   <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container d-flex justify-content-between">
      <a href="#" class="navbar-brand d-flex align-items-center"> 

      </a>
    </div>
  </div>
</head>
    

<body>



 

    <link rel="stylesheet" href="style.css">

<div style="background-image: url(fondo.png); background-repeat: no-repeat; background-size: 1720px 1300px" >

<script type="text/javascript">
  
function Eliminar(id)
{
  if (confirm("¿Estas seguro de querer eliminar el registro?"))
    {
      location.href = "usuarios.php?id_eliminar=" + id;
    }
}



</script>

<script type="text/javascript">
  


function Modificar(id)
{
  if (confirm("¿Estas seguro de querer modificar el registro?"))
    {
      location.href = "usuarios.php?id_modificar=" + id;
    }
}


function Sololetras(e)
{
 
 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 123456789";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


</script>




  <form action= usuarios.php method="post">  <div > 
  <div class="container" > <div class="container" > 
    <div class="text-center"> <div align="to top" style=" background: linear-gradient(to
      bottom,#, );  } width: 150%; box-shadow: 46px 40px 45px;
 border-radius: 20px 20px 15px "align="center">
<center>

  <section class="form-register">


    <h1 style = font-family:Times New Roman>Registrar Usuario.</h1> 
 
 <br>
      <div class="row" hidden> 
        <div class="col-lg-4"></div> 
        <select class="controls"  type="text" id="txtid" name="txtid" style = font-family:Times New Roman placeholder="Id" class="form-control" value="<?php echo $modificarx[0]['id_usuario']; ?>">>   

        </select>
        <div class="col-lg-4"></div>
      </div>
      



      <div class="row">

                          <div class="col-lg-3"></div>
        <div class="col-lg-1"><label style = font-family:Times New Roman>Nombre usuario.</label></div>
        <div class="col-lg-5">

          <center>  <p>  <input class="controls"  type="text" id="txtnombre_usuario" name="txtnombre_usuario"style = font-family:Times New Roman placeholder="Ingresar nombre." minlength="2" maxlength="76" class="form-control" value="<?php echo @$modificarx[0]['nombre_usuario']; ?>" required> </p>
        
                 </div>
        
        
      </div>

      
        <div class="row">
<br>
                          <div class="col-lg-3"></div>
        <div class="col-lg-1"><label style = font-family:Times New Roman>Correo.</label></div>
        <div class="col-lg-5">


           <input class="controls"  type="email" id="txtcorreo" name="txtcorreo" style = font-family:Times New Roman placeholder="Ingrese correo." minlength="0" maxlength="32"   value="<?php echo @$modificarx[0][1]; ?>"  required> 
        </div>
                 </div>
      <br>
    
         

        
    <div class="row">

                          <div class="col-lg-3"></div>
        <div class="col-lg-1"><label style = font-family:Times New Roman>Password.</label></div>
        <div class="col-lg-5">


           <input class="controls"  type="password" id="txtpassword" name="txtpassword" style = font-family:Times New Roman placeholder="Ingresar password." minlength="0" maxlength="32"  value="<?php echo @$modificarx[0][2]; ?>"  required> 
        </div>
                 </div>
    
    <!--
        <div class="col-lg-1"><label style = font-family:Times New Roman>Seleccione un privilegio.</label></div>
        
       <select class="controls" type="text" id="txtprivilegio" name="txtprivilegio" required value="<?php echo @$privilegio_modificar[0][3] ?>">
                  <option value="">Seleccionar Tipo.</option>
                  <option value="Admin">Admin</option>
                       </select>

    
      <br>-->

          <br>
          <input class="controls" type="submit"  id="btnregistrar" name="btnregistrar" class="btn btn-success" value="<?php 
            if (isset($_GET['id_modificar']))
            {
              echo 'Modificar';
            }
            else
            {
              echo 'Registrar Usuario';
            }      ?>" >

 <div class="modal-footer"><a href="index.php">¿Ya tienes cuenta?</a></div>
        </div>
        <div class="col-lg-2"></div>

      </div>

    </div>  
  </div>
  </form>
<td>
  
<br>
<br>
<br>
<br>



      <div >  
    <form action= usuarios.php method="post">  <div > 
  <div class="container" > <div class="container" > 
    <div class="text-center"> <div align="to top" style=" background: linear-gradient(to
      bottom,#556762, white);  } width: 100%; box-shadow: 26px 20px 15px;
 border-radius: 20px 20px 15px "align="center">
<center>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.slim.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  </div>
</body>

</html>