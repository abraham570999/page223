<?php 
session_start( );
error_reporting(1);

?><!DOCTYPE html>

  <head>

   
<html lang="en">

 

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="home.css">
<br>

    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
<br>
           <?php 
      require_once 'conexion_bd.php';

      $obj = new BD_PDO();

      if (isset($_POST['btniniciar']))
      { 
        $datos = $obj->Ejecutar_Instruccion("Select * from usuarios where correo  = '".$_POST['txtcorreo']."' and password = '".$_POST['txtpassword']."'");


        if (isset($datos))
        {
            $_SESSION['privilegio'] = $datos[0][4];
            $_SESSION['correo'] = $datos[0][2];
            $_SESSION['id_usuario']= $datos[0][0];          
          }
          else
          {
        echo '<script type="text/javascript">alert("Usuario y/o contraseña no existen")</script>';
        }
       }

       //var_dump($_POST['txtusuario'].$_SESSION['privilegio']);
      ?>
      <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 bg-light opacity-60" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><br><a class="navbar-brand" href="index.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/logo-s.png" alt="" width="50" />
          <br>
          <h3 style = font-family:Impact>LITTELFUSE.</h3></a>
          <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
             
            </ul>
            <form class="d-flex">
        
            </form>
          </div>
        </div>
      </nav>             
    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/faviconS.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/faviconS.png">

    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/faviconS.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="assets/css/theme.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/estilos.css">

  </head>


 
<body background="Le.jpeg">



      <br>
      <br>
      <br>


      <br>
      <br>
      <br>
      <br>
      <section class="py-0" id="header">
    
            


  <script>



function Sololetras(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 123456789";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


</script>  
              




  <header id="header" class="fixed-top d-flex align-items-center">

    <div class="container d-flex align-items-center justify-content-between">

      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->


      <nav id="navbar" class="navbar">
        <ul>
        <?php
           if (@$_SESSION['privilegio'] == "Admin")  
            {
        ?>
                          
                      
           <main class="main" id="top">
<br>

      <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 bg-light opacity-85" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand" href="index.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/logo-s.png" alt="" width="30" /><br><span style = font-family:Oregon LDO ></span></a>
          <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              
            



                        <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="notificacion.php">Notificacion.</a>



          
            </ul>
            <form class="d-flex">
        
            </form>
          </div>
        </div>
      </nav>             
                        
<!--  

<li class="nav-item"><a class="nav-link js-scroll-trigger" href="proveedores.php">proveedores</a></li>
<li class="nav-item"><a class="nav-link js-scroll-trigger" href="categoria.php">categoria</a></li>
<li class="nav-item"><a class="nav-link js-scroll-trigger" href="marcas.php">marcas</a></li>
<li class="nav-item"><a class="nav-link js-scroll-trigger" href="empcte.php">registro</a></li>
<li class="nav-item"><a class="nav-link js-scroll-trigger" href="usuarios.php">usuarios</a></li>
<li class="nav-item"><a class="nav-link js-scroll-trigger" href="productos.php">productos</a></li>
                               
-->




                         <?php

                           }
                          else
                           {
                           //header("Location: index.php");
                           }
                          ?>

<br>

     <br>
     <br>
     <br><br>
  <?php 
                            if (isset($_SESSION['correo'])) 
                            {
                                echo '<a <button class="btn btn-primary class="nav-link js-scroll-trigger"  class="navbar navbar-light grey bg-light grey
" href="cerrar_sesion.php" >Cerrar Sesión.</button> </a>';
                            }
                            else
                            {


                                echo  ' <button class="btn btn-primary class="nav-link js-scroll-trigger"  data-toggle="modal" data-target="#myModal">Iniciar Sesión.</button>';
                            }

?>



<?php 
                            if (isset($_SESSION['privilegio'])) 
                            {               
                                  
                                   if($_SESSION['privilegio']=='Admin')
                                   {
                                    
                                   }
                                   else
                                   {
                echo '<a class="p-2 text-muted" href="#"></a>
                 <a class="p-2 text-muted" href="busquedacategoria.php">Categoria</a>   
      <a class="p-2 text-muted" href="busquedacliente.php">Productos</a>                        ';
                                   }
                                   
                                 
                            }
                        ?>
   




        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!--  -->

    </div>
  </header><!-- End Header -->

    
  
  




                                   
                            <table>
 
   
</table>
    


</div>
</div>


<br>


               <body background="estudio.jpg"  id="page-top">       
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<div class="text-center">
                <a href="#myModal" class="trigger-btn" data-toggle="modal"></a>
            </div>   

        <!-- Modal HTML -->
        <div id="myModal" class="modal fade">
            <div class="modal-dialog modal-login">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Iniciar Sesión.</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form action="index.php" method="post">
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <input type="text" name="txtcorreo" class="form-control" id="txtcorreo" txtcorreo="correo" placeholder="Email." required="required">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="password" name="txtpassword" class="form-control" id="txtpassword" txtpassword="password" placeholder="password." required="required">


                                </div>
                            </div>
                            <div class="form-group">
                                 <button type="submit" id="btniniciar" name="btniniciar" class="btn btn-primary btn-block btn-lg">Iniciar sesión.</button>
                                 <button type="button" name="btniniciar" class="btn btn-danger" data-dismiss="modal">Cerrar sesión.</button>
                            </div>


                            <p class="hint-text"><a href="forgotPassword.php">¿Olvido su contraseña?</a></p>
                        </form>
                    </div>
                    <div class="modal-footer">¿No tienes cuenta? <a href="usuarios.php">Create una.</a></div>

                </div>
            </div>
        </div>

     



             
    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
  

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
 

    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="vendors/@popperjs/popper.min.js"></script>
    <script src="vendors/bootstrap/bootstrap.min.js"></script>
    <script src="vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="assets/js/theme.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Chivo:wght@300;400;700;900&amp;display=swap" rel="stylesheet">
  </body>

</html>