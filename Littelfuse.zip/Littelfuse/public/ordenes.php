<?php require 'conexion_bd.php';
    session_start();
    
    
 ?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
     <title>Littelfuse. </title>

  



   <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/faviconS.png">
    <link rel="icon" type="image/favicon-s.png" sizes="32x32" href="assets/img/favicons/faviconS.png">

    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/faviconS.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="assets/css/theme.css" rel="stylesheet" />
        <link href="assets/css/orden_diseño.css" rel="stylesheet" />

     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" href="not.css">
    <!-- GOOGLE FONTs -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <!-- ANIMATE CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  </head>


  <body>

    <?php  
error_reporting(1);

// Archivo que contiene la clase de conexion a la BD


// creacion del objeto de la conexion a la BD
$obj = new BD_PDO();

// Toma de decision que corresponde al boton de insertar
if (isset($_POST['btninsertar'])) 
{
  if ($_POST['btninsertar']=='Insertar') 
  {
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(" INSERT INTO ordenes(numero_de_orden, ubicacion_funcional, equipo, status, fecha_terminada)VALUES 

    ('".$_POST['txtnumero_de_orden']."',
     '".$_POST['txtubicacion_funcional']."',
     '".$_POST['txtequipo']."',
     '".$_POST['txtstatus']."',
     '".$_POST['txtfecha_terminada']."',
     '".$_POST['txtid']."')");
     

   echo '<script type="text/javascript">alert("Se ha realizado la orden.");</script>';
   }
  else
  {
  
  
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(  "update ordenes SET 



                                  numero_de_orden = '".$_POST['txtnumero_de_orden']."', 
                  ubicacion_funcional = '".$_POST['txtubicacion_funcional']."', 
                                            equipo = '".$_POST['txtequipo']."', 
                                            status = '".$_POST['txtstatus']."',
                              fecha_terminada = '".$_POST['txtfecha_terminada']."',  
                                where id_orden = '".$_POST['txtid']."'");



    echo '<script type="text/javascript">alert("notificacion modificada correctamente.");</script>';

  }  

} 


if(isset($_POST['btnbuscar']))
{

$buscar = $obj->Ejecutar_Instruccion("select * from ordenes where numero_de_orden like '".$_POST['txtnombrebuscar']."'");

}

if (isset($_GET['id_eliminar'])) 
{
  $obj->Ejecutar_Instruccion("delete from ordenes where id_orden = '".$_GET['id_eliminar']."'");

  echo '<script type="text/javascript">alert("Orden eliminada correctamente.");</script>';
}
if (isset($_GET['id_modificar'])) 
{
  $modificarx = $obj->Ejecutar_Instruccion("select * from ordenes where id_orden = '".$_GET['id_modificar']."'");

  $idmod = $obj->Ejecutar_Instruccion("select id_orden from ordenes where id_orden= '".$_GET['id_modificar']."'");

  $_SESSION['kikinasty'] = $_GET['id_modificar'];
}


 $ordenes = $obj->Ejecutar_Instruccion("Select * from ordenes");

$ordenes = $obj->Ejecutar_Instruccion("select * from ordenes where 1");

    ?>

<html lang="en">

<body style=" background: url('xx.jpg') no-repeat; background-size: cover;">



    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <br>
    <main class="main" id="top">
      <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 bg-light opacity-85" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand" href="Littelfuse_home.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/" alt="" width="50" /><br><span style = font-family:Times New Roman></span></a>
          <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse border-top border-lg-0  mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
             


          </div>
        </div>
      </nav>

      <br>
      <br>
      <br>
<br>
     <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-success">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
        <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" href="#">
          <i class="fa fa-bell">
            <span style = font-family:Times New Roman class="badge badge-success">LITTELFUSE.</span>
          </i>
         
        </a>
      </li>
     
     
      <li class="nav-item dropdown">
    
        <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" href="ordenes.php">
          <i class="fa fa-bell">
            <span  style = font-family:Times New Roman class="badge badge-success">Crear Orden.</span>
          </i>
        </a>
      </li>


      <li class="nav-item">
        <a class="nav-link" href="search_orden.php">
          <i class="fa fa-globe">
            <span style = font-family:Times New Roman class="badge badge-success">Buscar Orden.</span>
          </i>
        </a>
      </li>
    </ul>
</nav>
                    
        <!--/.bg-holder-->

        
        <!--/.bg-holder-->

</script>

<script type="text/javascript">
  
function Eliminar(id)
{
  if (confirm("¿Estas seguro de querer eliminar la notificacion?"))
    {
      location.href = "ordenes.php?id_eliminar=" + id;
    }
}



</script>

<script type="text/javascript">
  


function Modificar(id)
{
  if (confirm("¿Estas seguro de querer modificar la notificacion?"))
    {
      location.href = "ordenes.php?id_modificar=" + id;
    }
}



function Sololetras(e)
{
 
 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 1234567890";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


</script>
    <main class="main" id="top">
      <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 bg-light opacity-85" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand" href="index.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/logo-s.png" alt="" width="50" /><br><span style = font-family:Times New Roman>Littelfuse.</span></a>
          <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li style = font-family:Times New Roman class="nav-item px-2"><a class="nav-link fw-medium active" aria-current="page" href="index.php">INICIO.</a></li>
              <li style = font-family:Times New Roman class="nav-item px-2"><a class="nav-link fw-medium" href="ordenes.php">Ordenes.</a></li>
              <li style = font-family:Times New Roman class="nav-item px-2"><a class="nav-link fw-medium" href="notificacion.php">Notificación.</a></li>
             
            </ul>
            <form class="d-flex">
        
            </form>
          </div>
        </div>
      </nav>








  <form action="ordenes.php" method="post">  <div > 



   <a class="navbar-brand" href="#">
  </a>
  
</nav>

<br>

      <div class="row" hidden> 
        <div class="col-lg-4"></div> 
        <div class="col-lg-4">
          <input type="text" id="txtid" name="txtid" class="form-control" value="<?php echo $productomodificar[0]['id_orden']; ?>">
        </div>
        <div class="col-lg-4"></div>
      </div>


<br>

          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Times New Roman class="col-lg-1"><label style = font-family:Times New Roman>Numero De Orden:</label></div>
        <div class="col-lg-5">

          <center>  <p>  <input type="text" id="txtnumero_de_orden" name="txtnumero_de_orden"style = font-family:Times New Roman placeholder="Ingresar numero de orden."  minlength="0" maxlength="50" onkeypress="return Solonumeros(event)" class="form-control" value="<?php echo @$modificarx[0][0]; ?>" required> </p>
        
                 </div>
        

        <div class="col-lg-4"></div>
      </div>
      <br>

          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Times New Roman class="col-lg-1"><label   style = font-family:Times New Roman>Ubicación funcional:</label></div>
        <div class="col-lg-5">

             <select class="form-control" type="text" id="txtubicacion_funcional" name="ubicacion_funcional" required value="<?php echo @$modificarx[0][1]; ?>" required>  </p>


                  <option value="">Por Favor, Seleccione uno.</option>
                  <option value="ubicacion_funcional">D1 - Des Plaines Facility.</option>
                  <option value="ubicacion_funcional">D1-A - Des Plaines - Automotive.</option>
                  <option value="ubicacion_funcional">D1-A-501 - Des Plaines - Automotive - Molding.</option>
                  <option value="ubicacion_funcional">D1-A-502 Des Plaines - Automotive - Punch Press.</option>
                  <option value="ubicacion_funcional">D1-A-503 Des Plaines - Automotive - Four Slide.</option>
                  <option value="ubicacion_funcional">D1-A-504 Des Plaines - Automotive - Plating.</option>
                  <option value="ubicacion_funcional">D1-A-508 Des Plaines - Automotive - Fuse Plating.</option>
                  <option value="ubicacion_funcional">D1-A-509 Des Plaines - Automotive - Skiving.</option>
                  <option value="ubicacion_funcional">D1-A-520 Des Plaines - Automotive - Jcase.</option>
                  <option value="ubicacion_funcional">D1-A-522 Des Plaines - Automotive - Mini Fuse.</option>
                  <option value="ubicacion_funcional">D1-A-523 Des Plaines - Automotive - Maxi Fuse.</option>
                  <option value="ubicacion_funcional">D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.</option>
                  <option value="ubicacion_funcional">D1-A-543 Des Plaines - Automotive - Molding Mini.</option>
                  <option value="ubicacion_funcional">D1-A-544 Des Plaines - Automotive - Molding Maxi.</option>
                  <option value="ubicacion_funcional">D1-A-545 Des Plaines - Automotive - Molding ATO.</option>
                  <option value="ubicacion_funcional">D1-A-546 Des Plaines - Automotive - Molding Jcase.</option>
                  <option value="ubicacion_funcional">D1-A-592 Des Plaines - Automotive - Inspection.</option>
                  <option value="ubicacion_funcional">D1-A-593 Des Plaines - Automotive - Product Eval.</option>
                  <option value="ubicacion_funcional">D1-E Des Plaines - Electronics.</option>
                  <option value="ubicacion_funcional">D1-E-504 Des Plaines - Electronics - Plating.</option>
                  <option value="ubicacion_funcional">D1-E-510 Des Plaines - Electronics - Pulse Gard.</option>
                  <option value="ubicacion_funcional">D1-E-512 Des Plaines - Electronics - 0402.</option>
                  <option value="ubicacion_funcional">D1-E-514 Des Plaines - Electronics - Slim 1206.</option>
                  <option value="ubicacion_funcional">D1-E-515 Des Plaines - Electronics - Stencil/Dice.</option>
                  <option value="ubicacion_funcional">D1-E-516 Des Plaines - Elec - Surface Mnt Telecom.</option>
                  <option value="ubicacion_funcional">D1-E-517 Des Plaines - Electronics - Inspection.</option>
                  <option value="ubicacion_funcional">D1-E-518 Des Plaines - Elec - Compounding/Extrusn.</option>
                  <option value="ubicacion_funcional">D1-E-519 Des Plaines - Electronics - Thim Film.</option>
                  <option value="ubicacion_funcional">D1-E-532 Des Plaines - Electronics - Drilling.</option>






                       </select>




        </div>
        
      </div>

    

       <div class="col-lg-4"></div>
      </div>
      <br>

          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Times New Roman class="col-lg-1"><label   style = font-family:Times New Roman>Equipo:</label></div>
        <div class="col-lg-5">

             <select class="form-control" type="text" id="txtequipo" name="txtequipo" required value="<?php echo @$modificarx[0][2]; ?>" required>  </p>




                  <option value="">Por Favor, Seleccione uno.</option>
                  <option value="ubicacion_funcional">D1 - Des Plaines Facility.</option>
                  <option value="ubicacion_funcional">D1-A - Des Plaines - Automotive.</option>
                  <option value="ubicacion_funcional">D1-A-501 - Des Plaines - Automotive - Molding.</option>
                  <option value="ubicacion_funcional">D1-A-502 Des Plaines - Automotive - Punch Press.</option>
                  <option value="ubicacion_funcional">D1-A-503 Des Plaines - Automotive - Four Slide.</option>
                  <option value="ubicacion_funcional">D1-A-504 Des Plaines - Automotive - Plating.</option>
                  <option value="ubicacion_funcional">D1-A-508 Des Plaines - Automotive - Fuse Plating.</option>
                  <option value="ubicacion_funcional">D1-A-509 Des Plaines - Automotive - Skiving.</option>
                  <option value="ubicacion_funcional">D1-A-520 Des Plaines - Automotive - Jcase.</option>
                  <option value="ubicacion_funcional">D1-A-522 Des Plaines - Automotive - Mini Fuse.</option>
                  <option value="ubicacion_funcional">D1-A-523 Des Plaines - Automotive - Maxi Fuse.</option>
                  <option value="ubicacion_funcional">D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.</option>
                  <option value="ubicacion_funcional">D1-A-543 Des Plaines - Automotive - Molding Mini.</option>
                  <option value="ubicacion_funcional">D1-A-544 Des Plaines - Automotive - Molding Maxi.</option>
                  <option value="ubicacion_funcional">D1-A-545 Des Plaines - Automotive - Molding ATO.</option>
                  <option value="ubicacion_funcional">D1-A-546 Des Plaines - Automotive - Molding Jcase.</option>
                  <option value="ubicacion_funcional">D1-A-592 Des Plaines - Automotive - Inspection.</option>
                  <option value="ubicacion_funcional">D1-A-593 Des Plaines - Automotive - Product Eval.</option>
                  <option value="ubicacion_funcional">D1-E Des Plaines - Electronics.</option>
                  <option value="ubicacion_funcional">D1-E-504 Des Plaines - Electronics - Plating.</option>
                  <option value="ubicacion_funcional">D1-E-510 Des Plaines - Electronics - Pulse Gard.</option>
                  <option value="ubicacion_funcional">D1-E-512 Des Plaines - Electronics - 0402.</option>
                  <option value="ubicacion_funcional">D1-E-514 Des Plaines - Electronics - Slim 1206.</option>
                  <option value="ubicacion_funcional">D1-E-515 Des Plaines - Electronics - Stencil/Dice.</option>
                  <option value="ubicacion_funcional">D1-E-516 Des Plaines - Elec - Surface Mnt Telecom.</option>
                  <option value="ubicacion_funcional">D1-E-517 Des Plaines - Electronics - Inspection.</option>
                  <option value="ubicacion_funcional">D1-E-518 Des Plaines - Elec - Compounding/Extrusn.</option>
                  <option value="ubicacion_funcional">D1-E-519 Des Plaines - Electronics - Thim Film.</option>
                  <option value="ubicacion_funcional">D1-E-532 Des Plaines - Electronics - Drilling.</option>

                       </select>




        </div>
        
      </div>




        <div class="col-lg-4"></div>
      </div>
      <br>

          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Times New Roman class="col-lg-1"><label   style = font-family:Times New Roman>Estado:</label></div>
        <div class="col-lg-5">

             <select class="form-control" type="text" id="txtstatus" name="status" required value="<?php echo @$modificarx[0][3]; ?>" required>  </p>


                  <option value="">Por Favor, Seleccione uno.</option>
                  <option value="ubicacion_funcional">Todos</option>
                  <option value="ubicacion_funcional">Completado</option>
                  <option value="ubicacion_funcional">Abiertos</option>
         


                       </select>




        </div>
        
      </div>
<br>

 <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Times New Roman class="col-lg-1"><label style = font-family:Times New Roman>Fecha Terminada:</label></div>
        <div class="col-lg-5">

  

<p> <input  style="display:" accept="application/pdf" type="datetime-local" id="txtfecha_terminada" name="txtfecha_terminada" class="form-control" class="col-md-7" value="<?php echo date('Y-m-d'); ?>"onkeypress="return Solonumeros(event)" class="form-control" value="<?php echo @$modificarx[0][4]; ?>" required> </p>


          </div>
      </div>
<br>
  

      


<div align="center">
      <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
          <br>
          <input type="submit"  id="btninsertar" name="btninsertar" class="btn btn-secondary" value="<?php 
            if (isset($_GET['id_modificar']))
            {
              echo 'Modificar';
            }
            else
            {
              echo 'Insertar';
            }      ?>" >
        </div>
        <div class="col-lg-3"></div>
      </div>
      <br>
    </div>    
  </div>
  </form>
</div>
<br>
<br>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
   <a class="navbar-brand" href="#">
  </a>
  
</nav>
<br>
<br>

    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="vendors/@popperjs/popper.min.js"></script>
    <script src="vendors/bootstrap/bootstrap.min.js"></script>
    <script src="vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="assets/js/theme.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Chivo:wght@300;400;700;900&amp;display=swap" rel="stylesheet">
  </body>

</html>