<?php require 'conexion_bd.php';
    session_start();
    
    
 ?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
     <title>Littelfuse. </title>

  



   <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/faviconS.png">
    <link rel="icon" type="image/favicon-s.png" sizes="32x32" href="assets/img/favicons/faviconS.png">

    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/faviconS.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="assets/css/theme.css" rel="stylesheet" />

    <link href="assets/css/fom_notificacion.css" rel="stylesheet" />

     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
    <link rel="stylesheet" href="not.css">
    <!-- GOOGLE FONTs -->
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <!-- ANIMATE CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  </head>


  <body>

    <?php  
error_reporting(1);

// Archivo que contiene la clase de conexion a la BD


// creacion del objeto de la conexion a la BD
$obj = new BD_PDO();

// Toma de decision que corresponde al boton de insertar
if (isset($_POST['btninsertar'])) 
{
  if ($_POST['btninsertar']=='Insertar') 
  {
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(" INSERT INTO notificacion (descripcion, descripcion_del_equipo, ubicacion_funcional, equipo, planta, SBU, nombre_usuario1, fecha_de_mal_funcionamiento, id_notificacion)VALUES 

    ('".$_POST['txtdescripcion']."',
     '".$_POST['txtdescripcion_del_equipo']."',
     '".$_POST['txtubicacion_funcional']."',
     '".$_POST['txtequipo']."',
     '".$_POST['txtplanta']."',
     '".$_POST['txtSBU']."',
     '".$_POST['txtnombre_usuario1']."',
     '".$_POST['txtfecha_de_mal_funcionamiento']."',
     '".$_POST['txtid_notificacion']."')");
     
   echo '<script type="text/javascript">alert("Se ha realizado la notificación.");</script>';
   }
  else
  {
  
  
    // Instruccion sql para insertar un registro en la tabla notificación
    $obj->Ejecutar_Instruccion(  "update cerrar_notificacion SET 



                                  descripcion = '".$_POST['txtdescripcion']."', 
                                   descripcion_del_equipo = '".$_POST['txtdescripcion_del_equipo']."', 
                  ubicacion_funcional = '".$_POST['txtubicacion_funcional']."', 
                                            equipo = '".$_POST['txtequipo']."', 
                                            planta = '".$_POST['txtplanta']."',
                                                  SBU = '".$_POST['txtSBU']."', 
                              nombre_usuario1 = '".$_POST['txtnombre_usuario1']."',  
 
                                       id_notificacion = '".$_POST['txtid_notificacion']."' 
                                where id_notificacion = '".$_POST['txtid_notificacion']."'");



    echo '<script type="text/javascript">alert("notificacion modificada correctamente.");</script>';

  }  

} 


if(isset($_POST['btnbuscar']))
{

$buscar = $obj->Ejecutar_Instruccion("select * from cerrar_notificacion ");

}

if (isset($_GET['id_eliminar'])) 
{
  $obj->Ejecutar_Instruccion("delete from notificacion where id_notificacion = '".$_GET['id_eliminar']."'");

  echo '<script type="text/javascript">alert("notificacion eliminada correctamente.");</script>';
}
if (isset($_GET['id_modificar'])) 
{
  $modificarx = $obj->Ejecutar_Instruccion("select * from cerrar_notificacion where id_notificacion = '".$_GET['id_modificar']."'");

  $idmod = $obj->Ejecutar_Instruccion("select id_notificacion from cerrar_notificacion where id_notificacion= '".$_GET['id_modificar']."'");

  $_SESSION['kikinasty'] = $_GET['id_modificar'];
}


 $cerrar_notificacion = $obj->Ejecutar_Instruccion("Select * from cerrar_notificacion");

$cerrar_notificacion= $obj->Ejecutar_Instruccion("select * from cerrar_notificacion where 1");

    ?>

<html lang="en">




    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <br>
    <main class="main" id="top">
      <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 bg-light opacity-85" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand" href="Littelfuse_home.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/" alt="" width="50" /><br><span style = font-family:Times New Roman></span></a>
          <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse border-top border-lg-0  mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
             
<body style=" background: url('Le.jpeg') no-repeat; background-size: cover;">


          </div>
        </div>
      </nav>

      <br>
      <br>
      <br>
<br>
     <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
        <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" href="#">
          <i class="fa fa-bell">
            <span   class="badge badge-primary">LITTELFUSE.</span>
          </i>
         
        </a>
      </li>
     
     
      <li class="nav-item dropdown">
    
        <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" href="notificacion.php">
          <i class="fa fa-bell">
            <span class="badge badge-primary">Crear una notificación.</span>
          </i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="search.php">
          <i class="fa fa-globe">
            <span class="badge badge-primary">Buscar notificación.</span>
          </i>
        </a>
      </li>
    </ul>
</nav>         
        <!--/.bg-holder-->

        
        <!--/.bg-holder-->

</script>

<script type="text/javascript">
  
function Eliminar(id)
{
  if (confirm("¿Estas seguro de querer eliminar la notificacion?"))
    {
      location.href = "notificacion.php?id_eliminar=" + id;
    }
}



</script>

<script type="text/javascript">
  


function Modificar(id)
{
  if (confirm("¿Estas seguro de querer modificar la notificacion?"))
    {
      location.href = "cerrar_notificacion.php?id_modificar=" + id;
    }
}



function Sololetras(e)
{
 
 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " abcdefghijklmnñopqrstuvwxyz";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


function Solonumeros(e)
{

 var estatus = false;

key = e.keyCode || e.which;
tecla = String.fromCharCode(key).toLowerCase();

letras = " 1234567890";

for(var i = 0; i < letras.length ; i++)

{ 
  if (tecla == letras[i])
      { 

        estatus = true;
   
   }

   }

   return estatus;

   }


</script>
    <main class="main" id="top">
      <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 bg-light opacity-85" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand" href="index.php"><img class="d-inline-block align-top img-fluid" src="assets/img/gallery/logo-s.png" alt="" width="50" /><br><span style = font-family:Impact>Littelfuse.</span></a>
          <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
             
     <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="index.php">Inicio.</a>



                        <a  style = font-family:Impact class="nav nav-pills navbar navbar-expand-sm bg-light justify-content-center" href="notificacion.php">Notificacion.</a>



           
            </ul>
            <form class="d-flex">
        
            </form>
          </div>
        </div>
      </nav>








  <form action="notificacion.php" method="post">  <div > 



   <a class="navbar-brand" href="#">
  </a>
  
</nav>

<br>

<h1> <center>  <pre style = font-family:Impact>Registrar Notificación.</pre></h1>
      
      <br>
      <div class="row">

                          <div class="col-lg-3"></div>
        <div style="color=white" class="col-lg-1"><label style = font-family:Impact hidden="">Notificación Id:</label></div>
        <div class="col-lg-5">


    <input type="text" id="txtid_notificacion"name="txtid_notificacion" onkeypress="return Solonumeros(event)" hidden="" minlength="0" maxlength="31"  style = font-family:Impact placeholder="Id"  class="form-control" value="<?php echo $modificarx[0]['id_notificacion']; ?>">
        </div>
        <div class="col-lg-4"></div>
      </div>

<br>

          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>Descripción:</label></div>
        <div class="col-lg-5">

          <center>  <p>  <input type="text" id="txtdescripcion" name="txtdescripcion"style = font-family: placeholder="Ingresar descripción."  minlength="0" maxlength="100" class="form-control" value="<?php echo @$modificarx[0][0]; ?>" required> </p>
        
                 </div>
        

        <div class="col-lg-4"></div>
      </div>


          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>Descripción Del Equipo:</label></div>
        <div class="col-lg-5">

          <center>  <p>  <input type="text" id="txtdescripcion_del_equipo" name="txtdescripcion_del_equipo"style = font-family: placeholder="Ingresar descripción del equipo."  minlength="0" maxlength="100" class="form-control" value="<?php echo @$modificarx[0][1]; ?>" required> </p>
        
                 </div>
        

        <div class="col-lg-4"></div>
      </div>
      <br>

          <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label   style = font-family:impact>Ubicación funcional:</label></div>
        <div class="col-lg-5">

             <select class="form-control" type="text" id="txtubicacion_funcional" name="txtubicacion_funcional" required value="<?php echo @$modificarx[0][2]; ?>" required>  </p>

              
                  <option value="">Por Favor, Seleccione uno.</option>
                  <option value="D1 - Des Plaines Facility." <?php if ($modificarx[0]['ubicacion_funcional']=='D1 - Des Plaines Facility.'){echo 'Selected';} ?>>D1 - Des Plaines Facility.</option>

                  <option >D1-A - Des Plaines - Automotive.</option>

                  <option value="D1-A-501 - Des Plaines - Automotive - Molding." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-501 - Des Plaines - Automotive - Molding.'){echo 'Selected';} ?> value="ubicacion_funcional">D1-A-501 - Des Plaines - Automotive - Molding.</option>

                  <option value="D1-A-502 Des Plaines - Automotive - Punch Press." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-502 Des Plaines - Automotive - Punch Press.'){echo 'Selected';} ?>>D1-A-502 Des Plaines - Automotive - Punch Press.</option>

                  <option value="D1-A-503 Des Plaines - Automotive - Four Slide." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-503 Des Plaines - Automotive - Four Slide.'){echo 'Selected';} ?>>D1-A-503 Des Plaines - Automotive - Four Slide.</option>

                  <option value="D1-A-504 Des Plaines - Automotive - Plating." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-504 Des Plaines - Automotive - Plating.'){echo 'Selected';} ?>>D1-A-504 Des Plaines - Automotive - Plating.</option>

                  <option value="D1-A-508 Des Plaines - Automotive - Fuse Plating." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-508 Des Plaines - Automotive - Fuse Plating.'){echo 'Selected';} ?>>D1-A-508 Des Plaines - Automotive - Fuse Plating.</option>

                  <option value="D1-A-509 Des Plaines - Automotive - Skiving." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-509 Des Plaines - Automotive - Skiving.'){echo 'Selected';} ?>>D1-A-509 Des Plaines - Automotive - Skiving.</option>

                  <option value="D1-A-520 Des Plaines - Automotive - Jcase." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-520 Des Plaines - Automotive - Jcase.'){echo 'Selected';} ?>>D1-A-520 Des Plaines - Automotive - Jcase.</option>

                  <option value="D1-A-522 Des Plaines - Automotive - Mini Fuse." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-522 Des Plaines - Automotive - Mini Fuse.'){echo 'Selected';} ?>>D1-A-522 Des Plaines - Automotive - Mini Fuse.</option>

                  <option value="D1-A-523 Des Plaines - Automotive - Maxi Fuse." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-523 Des Plaines - Automotive - Maxi Fuse.'){echo 'Selected';} ?>>D1-A-523 Des Plaines - Automotive - Maxi Fuse.</option>

                  <option value="D1-A-525 Des Plaines - Automotive - ATO/Mini Diode." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.'){echo 'Selected';} ?>>D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.</option>

                  <option value="D1-A-543 Des Plaines - Automotive - Molding Mini." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-543 Des Plaines - Automotive - Molding Mini.'){echo 'Selected';} ?>>D1-A-543 Des Plaines - Automotive - Molding Mini.</option>

                  <option value="D1-A-544 Des Plaines - Automotive - Molding Maxi." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-544 Des Plaines - Automotive - Molding Maxi.'){echo 'Selected';} ?>>D1-A-544 Des Plaines - Automotive - Molding Maxi.</option>

                  <option value="D1-A-545 Des Plaines - Automotive - Molding ATO." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-545 Des Plaines - Automotive - Molding ATO.'){echo 'Selected';} ?>>D1-A-545 Des Plaines - Automotive - Molding ATO.</option>

                  <option value="D1-A-546 Des Plaines - Automotive - Molding Jcase." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-546 Des Plaines - Automotive - Molding Jcase.'){echo 'Selected';} ?>>D1-A-546 Des Plaines - Automotive - Molding Jcase.</option>

                  <option value="D1-A-592 Des Plaines - Automotive - Inspection." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-592 Des Plaines - Automotive - Inspection.'){echo 'Selected';} ?>>D1-A-592 Des Plaines - Automotive - Inspection.</option>

                  <option value="D1-A-593 Des Plaines - Automotive - Product Eval." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-A-593 Des Plaines - Automotive - Product Eval.'){echo 'Selected';} ?>>D1-A-593 Des Plaines - Automotive - Product Eval.</option>

                  <option value="D1-E Des Plaines - Electronics." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E Des Plaines - Electronics.'){echo 'Selected';} ?>>D1-E Des Plaines - Electronics.</option>

                  <option value="D1-E-504 Des Plaines - Electronics - Plating." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-504 Des Plaines - Electronics - Plating.'){echo 'Selected';} ?>>D1-E-504 Des Plaines - Electronics - Plating.</option>

                  <option value="D1-E-510 Des Plaines - Electronics - Pulse Gard." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-510 Des Plaines - Electronics - Pulse Gard.'){echo 'Selected';} ?>>D1-E-510 Des Plaines - Electronics - Pulse Gard.</option>

                  <option value="D1-E-512 Des Plaines - Electronics - 0402." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-512 Des Plaines - Electronics - 0402.'){echo 'Selected';} ?>>D1-E-512 Des Plaines - Electronics - 0402.</option>

                  <option value="D1-E-514 Des Plaines - Electronics - Slim 1206." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-514 Des Plaines - Electronics - Slim 1206.'){echo 'Selected';} ?>>D1-E-514 Des Plaines - Electronics - Slim 1206.</option>

                  <option value="D1-E-515 Des Plaines - Electronics - Stencil/Dice." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-515 Des Plaines - Electronics - Stencil/Dice.'){echo 'Selected';} ?>>D1-E-515 Des Plaines - Electronics - Stencil/Dice.</option>

                  <option value="D1-E-516 Des Plaines - Elec - Surface Mnt Telecom." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-516 Des Plaines - Elec - Surface Mnt Telecom.'){echo 'Selected';} ?>>D1-E-516 Des Plaines - Elec - Surface Mnt Telecom.</option>

                  <option value="D1-E-517 Des Plaines - Electronics - Inspection." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-517 Des Plaines - Electronics - Inspection.'){echo 'Selected';} ?>>D1-E-517 Des Plaines - Electronics - Inspection.</option>

                  <option value="D1-E-518 Des Plaines - Elec - Compounding/Extrusn." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-518 Des Plaines - Elec - Compounding/Extrusn.'){echo 'Selected';} ?>>D1-E-518 Des Plaines - Elec - Compounding/Extrusn.</option>

                  <option value="D1-E-519 Des Plaines - Electronics - Thim Film." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-519 Des Plaines - Electronics - Thim Film.'){echo 'Selected';} ?>>D1-E-519 Des Plaines - Electronics - Thim Film.</option>

                  <option value="D1-E-532 Des Plaines - Electronics - Drilling." <?php if ($modificarx[0]['ubicacion_funcional']=='D1-E-532 Des Plaines - Electronics - Drilling.'){echo 'Selected';} ?>>D1-E-532 Des Plaines - Electronics - Drilling.</option>

                       </select>
        </div>
        
      </div>

    

      <br>
      <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>Equipo:</label></div>
        <div class="col-lg-5">

        <center>  <p>    <input type="text" id="txtequipo" name="txtequipo" style = font-family: placeholder="Por favor, seleccione uno." minlength="" maxlength="" onkeypress="return (event)" class="form-control" value="<?php echo @$modificarx[0][3]; ?>" required> </p>

          </div>
      </div>

       <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>Planta:</label></div>
        <div class="col-lg-5">

      

<select class="form-control" id="txtplanta" name="txtplanta" required value="<?php echo @$modificarx[0][4] ?>">
                  <option value="">Por Favor, Seleccione uno.</option>
         <option value="">Por Favor, Seleccione uno.</option>
                  <option value="99 - Littelfuse - Mexico Auto Mfg." <?php if ($modificarx[0]['planta']=='99 - Littelfuse - Mexico Auto Mfg.'){echo 'Selected';} ?>>99 - Littelfuse - Mexico Auto Mfg.</option>

                  <option value="A1 - Littelfuse Inc." <?php if ($modificarx[0]['planta']=='A1 - Littelfuse Inc.'){echo 'Selected';} ?>>A1 - Littelfuse Inc.</option>

                  <option value="B1 - Littelfuse-Brazil." <?php if ($modificarx[0]['planta']=='B1 - Littelfuse-Brazil.'){echo 'Selected';} ?>>B1 - Littelfuse-Brazil.</option>

                  <option value="BS1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BS1 - Littelfuse, Inc.'){echo 'Selected';} ?>>BS1 - Littelfuse, Inc.</option>

                  <option value="BT1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BT1 - Littelfuse, Inc.'){echo 'Selected';} ?>>BT1 - Littelfuse, Inc.</option>

                  <option value="BV1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BV1 - Littelfuse, Inc.'){echo 'Selected';} ?>>BV1 - Littelfuse, Inc.</option>

                  <option value="BT1S - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BT1S - Littelfuse, Inc.'){echo 'Selected';} ?>>BT1S - Littelfuse, Inc.</option>

                  <option value="BVWS - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='BVWS - Littelfuse, Inc.'){echo 'Selected';} ?>>BVWS - Littelfuse, Inc.</option>

                  <option value="BW1 - SSAC." <?php if ($modificarx[0]['planta']=='BW1 - SSAC.'){echo 'Selected';} ?>>BW1 - SSAC.</option>

                  <option value="C1 - Littelfuse, Centralia." <?php if ($modificarx[0]['planta']=='C1 - Littelfuse, Centralia.'){echo 'Selected';} ?>>C1 - Littelfuse, Centralia.</option>

                  <option value="CN1 - LF Suzhou OVS Ltd.(Export)" <?php if ($modificarx[0]['planta']=='CN1 - LF Suzhou OVS Ltd.(Export)'){echo 'Selected';} ?>>CN1 - LF Suzhou OVS Ltd.(Export)</option>

                  <option value="CN2 - LF Suzhou OVS Ltd.(Domestiq)" <?php if ($modificarx[0]['planta']=='CN2 - LF Suzhou OVS Ltd.(Domestiq)'){echo 'Selected';} ?>>CN2 - LF Suzhou OVS Ltd.(Domestiq)</option>

                  <option value="CN3 - LF Hamlin Electronics Ltd." <?php if ($modificarx[0]['planta']=='CN3 - LF Hamlin Electronics Ltd.'){echo 'Selected';} ?>>CN3 - LF Hamlin Electronics Ltd.</option>

                  <option value="D1 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='D1 - Littelfuse, Inc.'){echo 'Selected';} ?>>D1 - Littelfuse, Inc.</option>

                  <option value="D1S - LITTELFUSE - D.P. Samples." <?php if ($modificarx[0]['planta']=='D1S - LITTELFUSE - D.P. Samples.'){echo 'Selected';} ?>>D1S - LITTELFUSE - D.P. Samples.</option>

                  <option value="D2 - Littelfuse, Inc." <?php if ($modificarx[0]['planta']=='D2 - Littelfuse, Inc.'){echo 'Selected';} ?>>D2 - Littelfuse, Inc.</option>

                  <option value="DE1 - Littelfuse GmbH - D.P. Samples." <?php if ($modificarx[0]['planta']=='DE1 - Littelfuse GmbH - D.P. Samples.'){echo 'Selected';} ?>>DE1 - Littelfuse GmbH - D.P. Samples.</option>

                  <option value="DG1 - LF - Dongguan." <?php if ($modificarx[0]['planta']=='DG1 - LF - Dongguan.'){echo 'Selected';} ?>>DG1 - LF - Dongguan.</option>

                  <option value="DG2 - LF - Dongguan." <?php if ($modificarx[0]['planta']=='DG2 - LF - Dongguan.'){echo 'Selected';} ?>>DG2 - LF - Dongguan.</option>

                  <option value="DN1 - Littelfuse Europe GmbH." <?php if ($modificarx[0]['planta']=='DN1 - Littelfuse Europe GmbH.'){echo 'Selected';} ?>>DN1 - Littelfuse Europe GmbH.</option>

                  <option value="DN1S -Littelfuse GmbH - Samples." <?php if ($modificarx[0]['planta']=='DN1S -Littelfuse GmbH - Samples.'){echo 'Selected';} ?>>DN1S -Littelfuse GmbH - Samples.</option>

                  <option value="DN2 - Littelfuse Holding GmbH." <?php if ($modificarx[0]['planta']=='DN2 - Littelfuse Holding GmbH.'){echo 'Selected';} ?>>DN2 - Littelfuse Holding GmbH.</option>

                  <option value="E2 - Electric Sales Unlimited." <?php if ($modificarx[0]['planta']=='E2 - Electric Sales Unlimited.'){echo 'Selected';} ?>>E2 - Electric Sales Unlimited.</option>

                  <option value="F1 - LFFE - Hong Kong Dist. Ctr." <?php if ($modificarx[0]['planta']=='F1 - LFFE - Hong Kong Dist. Ctr.'){echo 'Selected';} ?>>F1 - LFFE - Hong Kong Dist. Ctr.</option>

                  <option value="F2 - LFFE - Hong Kong Dist. Ctr." <?php if ($modificarx[0]['planta']=='F2 - LFFE - Hong Kong Dist. Ctr.'){echo 'Selected';} ?>>F2 - LFFE - Hong Kong Dist. Ctr.</option>

                  <option value="G1 - G'Day Aftermarket Warehouse." <?php if ($modificarx[0]['planta']=='G1 - G Day Aftermarket Warehouse.'){echo 'Selected';} ?>>G1 - G'Day Aftermarket Warehouse.</option>

                  <option value="GB1 - Obsolete." <?php if ($modificarx[0]['planta']=='GB1 - Obsolete.'){echo 'Selected';} ?>>GB1 - Obsolete.</option>

                  <option value="HK1 - Littelfuse Hong Kong Limited." <?php if ($modificarx[0]['planta']=='HK1 - Littelfuse Hong Kong Limited.'){echo 'Selected';} ?>>HK1 - Littelfuse Hong Kong Limited.</option>

                  <option value="HN1 - Hamlin UK." <?php if ($modificarx[0]['planta']=='HN1 - Hamlin UK.'){echo 'Selected';} ?>>HN1 - Hamlin UK.</option>

                  <option value="11 - Obsolete." <?php if ($modificarx[0]['planta']=='11 - Obsolete.'){echo 'Selected';} ?>>11 - Obsolete.</option>


                       </select>
          </div>
      </div> 
      <br>

 <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>SBU:</label></div>
        <div class="col-lg-5">

  
       <select class="form-control" id="txtSBU" name="txtSBU" required value="<?php echo @$modificarx[0][5] ?>">
                  <option value="">Por Favor, Seleccione uno.</option>
                  <option value="ABU" <?php if ($modificarx[0]['SBU']=='ABU'){echo 'Selected';} ?>>ABU</option>
                  <option value="CVP" <?php if ($modificarx[0]['SBU']=='CVP'){echo 'Selected';} ?>>CVP</option>
                  <option value="EBU" <?php if ($modificarx[0]['SBU']=='EBU'){echo 'Selected';} ?>>EBU</option>
                  <option value="PBU" <?php if ($modificarx[0]['PBU']==''){echo 'Selected';} ?>>PBU</option>
                  <option value="SBU" <?php if ($modificarx[0]['SBU']=='SBU'){echo 'Selected';} ?>>SBU</option>
                       


                       </select>
          </div>
      </div>
<br>
       <div class="row">

                          <div class="col-lg-3"></div>
        <div style = font-family:Impact class="col-lg-1"><label style = font-family:Impact>Reportado por:</label></div>
        <div class="col-lg-5">

      
        <center>  <p>    <input type="text" id="txtnombre_usuario1" name="txtnombre_usuario1" style = font-family: placeholder="Por favor, seleccione uno." minlength="" maxlength="" onkeypress="return (event)" class="form-control" value="<?php echo @$modificarx[0][6]; ?>" required> </p>

          </div>
      </div>




      <div class="row">

                          <div class="col-lg-3"></div>
                          <br>
        <div style = font-family:Times New Roman class="col-lg-1"><label style = font-family:Impact  >Fecha del fallo:</label></div>
        <div class="col-lg-5">

          <br>

     
 
    </div>
      </div>
<center>  
    <div align="center">                        
<div class="col-lg-6">

<p> <input  style="display:" accept="application/pdf" type="datetime-local" id="txtfecha_de_mal_funcionamiento" name="txtfecha_de_mal_funcionamiento" class="form-control" class="col-md-7" value="?><?php echo date('Y-m-d'); ?>"onkeypress="return Solonumeros(event)" class="form-control" ></p>









<div align="center">
      <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
          <br>
          <input type="submit"  id="btninsertar" name="btninsertar" class="btn btn-primary btn-sm" value="<?php 
            if (isset($_GET['id_modificar']))
            {
              echo 'Modificar';
            }
            else
            {
              echo 'Insertar';
            }      ?>" >
        </div>
        <div class="col-lg-3"></div>
      </div>
      <br>
    </div>    
  </div>
  </form>
</div>
<br>
<br>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
   <a class="navbar-brand" href="#">
  </a>
  
</nav>
<br>
<br>

    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="vendors/@popperjs/popper.min.js"></script>
    <script src="vendors/bootstrap/bootstrap.min.js"></script>
    <script src="vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="assets/js/theme.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Chivo:wght@300;400;700;900&amp;display=swap" rel="stylesheet">
  </body>

</html>