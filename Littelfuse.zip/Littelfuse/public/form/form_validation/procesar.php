<?php
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$direccion = $_POST['direccion'];
$usuario = $_POST['usuario'];

echo "Recibimos... <br>";
echo "Nombre: ".$nombre."<br>";
echo "Apellido: ".$apellido."<br>";
echo "Direccion: ".$direccion."<br>";
echo "Nombre de usuario: ".$usuario."<br>";
