-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-10-2021 a las 05:03:31
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `littelfuse`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion`
--

CREATE TABLE `notificacion` (
  `descripcion` varchar(100) NOT NULL,
  `ubicacion_funcional` varchar(100) NOT NULL,
  `equipo` varchar(100) NOT NULL,
  `planta` varchar(100) NOT NULL,
  `SBU` varchar(100) NOT NULL,
  `reportado_por` varchar(100) NOT NULL,
  `fecha_de_mal_funcionamiento` date NOT NULL,
  `id_notificacion` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `notificacion`
--

INSERT INTO `notificacion` (`descripcion`, `ubicacion_funcional`, `equipo`, `planta`, `SBU`, `reportado_por`, `fecha_de_mal_funcionamiento`, `id_notificacion`) VALUES
('hola', 'jghjg', 'ghjhgjh', 'hjghjgjh', 'hjjhgjhgjh', 'jhghjh', '2021-10-29', 22222),
('trfr', 'fdf', 'fdfdf', 'dfd', 'dff', 'dff', '2021-10-23', 48888);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordenes`
--

CREATE TABLE `ordenes` (
  `ubicacion_funcional` varchar(50) NOT NULL,
  `fecha_programada` varchar(100) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `descripcion_del_equipo` varchar(50) NOT NULL,
  `equipo` varchar(50) NOT NULL,
  `id_orden` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ordenes`
--

INSERT INTO `ordenes` (`ubicacion_funcional`, `fecha_programada`, `descripcion`, `descripcion_del_equipo`, `equipo`, `id_orden`) VALUES
('hola', '2021-10-12T19:33', 'si', 'o', 'e', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` bigint(20) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `privilegio` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `correo`, `password`, `privilegio`) VALUES
(23, 'rggrtg', 'frr@gmail.com', '12345', 'Admin'),
(24, 'abraham', 'abraham@gmail.com', '123', 'Admin'),
(25, 'jhghgj', 'kh@gmail.com', '2323', 'Admin'),
(26, 'hjgjghjhjgjhgjh', 'gjhgjhgjh@gmail.com', 'jhkjhjk@gmail.com', 'Admin'),
(27, 'Laura', 'Laura@gmail.com', '12345', 'Admin');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `notificacion`
--
ALTER TABLE `notificacion`
  ADD PRIMARY KEY (`id_notificacion`);

--
-- Indices de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD PRIMARY KEY (`id_orden`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  MODIFY `id_orden` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
