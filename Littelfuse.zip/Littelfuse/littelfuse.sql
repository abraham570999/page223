-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-01-2022 a las 01:57:07
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `littelfuse`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion`
--

CREATE TABLE `notificacion` (
  `descripcion` varchar(100) NOT NULL,
  `descripcion_del_equipo` varchar(100) NOT NULL,
  `ubicacion_funcional` varchar(100) NOT NULL,
  `equipo` varchar(100) NOT NULL,
  `planta` varchar(100) NOT NULL,
  `SBU` varchar(100) NOT NULL,
  `reportado_por` bigint(20) NOT NULL,
  `fecha_de_mal_funcionamiento` datetime NOT NULL,
  `id_notificacion` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `notificacion`
--

INSERT INTO `notificacion` (`descripcion`, `descripcion_del_equipo`, `ubicacion_funcional`, `equipo`, `planta`, `SBU`, `reportado_por`, `fecha_de_mal_funcionamiento`, `id_notificacion`) VALUES
('Se sobrecarga', 'xxx', 'D1-A - Des Plaines - Automotive.', 'mantenimiento4', '99 - Littelfuse - Mexico Auto Mfg.', 'SBU', 31, '2021-12-07 15:19:17', 43556),
('Se calienta la maquinaria', 'maquina 5v', 'D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.', 'prueba', 'D1 - Littelfuse, Inc.', 'PBU', 31, '2021-12-07 15:26:56', 43557),
('Se calienta la maquinaria', 'maquina 5v', 'D1-A-525 Des Plaines - Automotive - ATO/Mini Diode.', 'prueba', 'D1 - Littelfuse, Inc.', 'PBU', 31, '2021-12-10 13:21:17', 43558);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordenes`
--

CREATE TABLE `ordenes` (
  `numero_de_orden` varchar(100) NOT NULL,
  `ubicacion_funcional` varchar(50) NOT NULL,
  `equipo` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `fecha_terminada` date NOT NULL,
  `id_orden` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ordenes`
--

INSERT INTO `ordenes` (`numero_de_orden`, `ubicacion_funcional`, `equipo`, `status`, `fecha_terminada`, `id_orden`) VALUES
('', 'hola', 'e', '2021-10-12T19:33', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` bigint(20) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `privilegio` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `correo`, `password`, `privilegio`) VALUES
(23, 'rggrtg', 'frr@gmail.com', '12345', 'Admin'),
(24, 'abraham', 'abraham@gmail.com', '123', 'Admin'),
(25, 'jhghgj', 'kh@gmail.com', '2323', 'Admin'),
(26, 'hjgjghjhjgjhgjh', 'gjhgjhgjh@gmail.com', 'jhkjhjk@gmail.com', 'Admin'),
(28, 'abraham@gmail.com', 'jhgjhghj@gmail.com', '123', 'Admin'),
(29, 'bananas', 'bananas@gmail.com', 'bananas', 'Admin'),
(30, 'ahdsd', 'dsds@gmail.com', 'erer', 'Admin'),
(31, 'Jaqueline', 'jaqui@gmail.com', 'tauro2001', 'Admin'),
(32, 'Jaqueline Mtz', 'jaqui2@gmail.com', 'tauro2001', 'Admin');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `notificacion`
--
ALTER TABLE `notificacion`
  ADD PRIMARY KEY (`id_notificacion`),
  ADD KEY `reportado_por` (`reportado_por`);

--
-- Indices de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD PRIMARY KEY (`id_orden`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `notificacion`
--
ALTER TABLE `notificacion`
  MODIFY `id_notificacion` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43559;

--
-- AUTO_INCREMENT de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  MODIFY `id_orden` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
